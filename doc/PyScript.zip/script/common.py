"""
Common utility functions for raw data parsing and analysis.
通用的原始数据解析和分析函数
"""

import pandas as pd
import numpy as np
import json
from script.data_structures import (
    BaseInfo,
    ACC_Raw_Data,
    PPG_Raw_Data,
    PSP_PPG_FIFO,
    WearInfo,
    MotionRecognition,
    TYHX_PPG_Data,
    TYHX_AGC_Data,
    TYHX_3697_Data
)
# from script.data_structures.wear_info import MotionRecognition


def parse_filename(filename) -> dict:
    """
    解析 rawdata 文件名,提取各项信息
    
    Parameters:
    -----------
    filename : str
        rawdata 文件名,格式为: CollectionMode_Label_Tester_Date_Time_MAC.rawdata
        例如: Wear_Wearing_yuyue_20251227_162142_0983.rawdata
    
    Returns:
    --------
    dict
        包含以下键值对的字典:
        - collection_mode: 采集模式(如 Wear, HeartRate 等)
        - label: 标签(如 Wearing, Unwear 等)
        - tester: 测试人员名称
        - date: 日期(格式:YYYYMMDD)
        - time: 时间(格式:HHMMSS)
        - mac: MAC地址后4位
        - filename: 原始文件名
        
        如果文件名格式无效,返回空字典
    """
    # 去掉扩展名
    name = filename.rsplit('.', 1)[0]
    parts = name.split('_')
    if len(parts) < 6:
        print(f"文件名格式无效: {filename}")
        return {}
    return {
        'collection_mode': parts[0],
        'label': parts[1],
        'tester': parts[2],
        'date': parts[3],
        'time': parts[4],
        'mac': parts[5],
        'filename': filename
    }

def process_ppg_dataframe(ppg_df,channel_num = 0):
    """处理PPG DataFrame,根据channel_num动态分离多通道数据"""
    if ppg_df is None or ppg_df.empty:
        return ppg_df
    

        
    # 确定 channel_num
    def get_channel_num(row):
        
        # 优先使用 data[0]
        if isinstance(row['data'], (list, np.ndarray)) and len(row['data']) > 0:
            return int(row['data'][0])
        # 其次判断 ppg_data 是否有值
        elif isinstance(row['ppg_data'], np.ndarray) and len(row['ppg_data']) > 0:
            return 1
        else:
            return 1
        
    if channel_num > 0:
        ppg_df['channel_num'] = channel_num
    else:
        ppg_df['channel_num'] = ppg_df.apply(get_channel_num, axis=1)
    
    # 找出最大通道数
    max_channel = int(ppg_df['channel_num'].max()) if not ppg_df.empty else 0
    
    # 为每个通道创建列
    def split_ppg_data(row):
        """根据channel_num分离ppg_data到多个通道
        列名规则:ppg_data_0(第1通道), ppg_data_1(第2通道), ppg_data_2(第3通道)...
        """
        channel_num = row['channel_num']
        ppg_data = row['ppg_data']
        
        result = {}
        
        if channel_num == 0 or not isinstance(ppg_data, np.ndarray) or len(ppg_data) == 0:
            # 没有数据,所有通道填充空数组
            for ch in range(max_channel):
                result[f'ppg_data_{ch}'] = np.array([])
        elif channel_num == 1:
            # 单通道数据,放到第一通道(ppg_data_0),其他通道填充空数组
            result['ppg_data_0'] = ppg_data
            for ch in range(1, max_channel):
                result[f'ppg_data_{ch}'] = np.array([])
        else:
            # 多通道数据,按交叉方式分离
            for ch in range(max_channel):
                if ch < channel_num:
                    # 提取对应通道的数据(每隔channel_num个取一个)
                    result[f'ppg_data_{ch}'] = ppg_data[ch::channel_num]
                else:
                    result[f'ppg_data_{ch}'] = np.array([])
        
        return pd.Series(result)
    
    # 应用分离函数
    if max_channel > 0:
        channel_data = ppg_df.apply(split_ppg_data, axis=1)
        ppg_df = pd.concat([ppg_df, channel_data], axis=1)
    
    return ppg_df



def get_raw_data(file_path, encoding='utf-8', is_ring=False) -> dict:
    """
    解析 rawdata 文件,提取各类传感器数据
    
    Parameters:
    -----------
    file_path : str
        rawdata 文件路径
    encoding : str, optional
        文件编码格式,默认为 'utf-8'
    
    Returns:
    --------
    dict
        包含以下键值对的字典:
        - base_info_df: 基础信息 DataFrame
        - wear_info_df: 佩戴信息 DataFrame
        - acc_df: 加速度数据 DataFrame
        - gyro_df: 陀螺仪数据 DataFrame
        - ppg_g_df: 绿光 PPG 数据 DataFrame
        - ppg_r_df: 红光 PPG 数据 DataFrame
        - ppg_ir_df: 红外光 PPG 数据 DataFrame
        - ppg_r_ir_df: 红外红光 PPG 数据 DataFrame
        - TYHX_data_df: TYHX 数据 DataFrame
        - TYHX_agc_data_df: TYHX AGC 数据 DataFrame
        - TYHX_3697_data_df: TYHX 3697 数据 DataFrame (戒指设备)
        - data_types: 数据类型统计字典
    Data Types:
    -----------
    00  BASE_INFO      - 基础信息
    15  RAW_PPG_GREEN  - 原始PPG绿光
    16  RAW_PPG_RED    - 原始PPG红光 
    17  RAW_PPG_IR     - 原始PPG红外光
    26  RAW_PPG_RED_IR - 原始PPG红灯红外  

    18  RAW_ACC        - 原始加速度数据
    19  RAW_GYRO       - 原始陀螺仪数据
    67  SLEEP_INFO     - 睡眠信息
    69  MOTION_INFO    - 运动信息
    71  WEAR_INFO      - 佩戴信息
    81  TYHX_DATA      - TYHX数据
    82  TYHX_AGC_Data  - TYHX AGC数据
    82  TYHX_3697_Data - TYHX 3697数据 (戒指设备)
    91  PSP_PPG_FIFO   - PSP PPG FIFO 数据
    """
    metadata = {
        'labels': [],
        'start_time': None,
        'device': None,
        'reference': None,
        'phone': None,
        'app_version': None,
        'user_info': None,
        'weather': None,
        'data_type': None,
        'sensor': None,
        'algorithm_info': None
    }

    result = {}
    data_type_dict = {}

    base_info_list = []
    wear_info_list = []

    acc_data_list = []
    pending_merge_acc = None

    gyro_data_list = []
    pending_merge_gyro = None

    ppg_g_data_list = []
    pending_merge_ppg_g = None

    ppg_r_data_list = []
    pending_merge_ppg_r = None

    ppg_ir_data_list = []
    pending_merge_ppg_ir = None
    
    ppg_r_ir_data_list = []
    pending_merge_ppg_r_ir = None

    motion_recognition_list = []

    psp_fifo_list = []

    TYHX_data_list = []
    TYHX_agc_data_list = []
    TYHX_3697_data_list = []

    last_unix_timestamp = 0
    with open(file_path, "r", encoding=encoding) as f:
        for line in f:
            line = line.strip()
            if line.startswith('202'):
                data = line.strip().replace(", ", ",").split(",")
                if data[3] != "52":
                    continue

                data_type = data[4]
                unix_timestamp = int(''.join(data[6:10]), 16)
                last_unix_timestamp = unix_timestamp
                label_hr = int(data[2], 16)
                rawdata_v2 = len(data) == 243
                data_bytes = bytes.fromhex(''.join(data[10:]))
                
                if data_type not in data_type_dict:
                    data_type_dict[data_type] = 1
                else:
                    data_type_dict[data_type] += 1

                if data_type == "00":  # BASE_INFO
                    data = BaseInfo.from_bytes(data_bytes, rawdata_v2, unix_timestamp=unix_timestamp, label_hr=label_hr)
                    base_info_list.append(data)

                elif data_type == "18":  # RAW_ACC_XYZ
                    acc = ACC_Raw_Data.from_bytes(data_bytes, rawdata_v2, unix_timestamp)
                    # 检查是否需要与上一个数据合并
                    if pending_merge_acc is not None:
                        if pending_merge_acc.serial_number == acc.serial_number:
                            pending_merge_acc.acc_data += acc.acc_data
                            pending_merge_acc.arr_size += acc.arr_size
                        else:
                            # 不同serial_number,将之前的数据添加到列表
                            pending_merge_acc.acc_data = np.array(pending_merge_acc.acc_data)  # type: ignore
                            acc_data_list.append(pending_merge_acc)
                            pending_merge_acc = acc
                    else:
                        # 第一个数据,暂存
                        pending_merge_acc = acc

                elif data_type == "19":  # RAW_GYRO
                    gyro = ACC_Raw_Data.from_bytes(data_bytes, rawdata_v2, unix_timestamp)
                    # 检查是否需要与上一个数据合并
                    if pending_merge_gyro is not None:
                        if pending_merge_gyro.serial_number == gyro.serial_number:
                            pending_merge_gyro.acc_data += gyro.acc_data
                            pending_merge_gyro.arr_size += gyro.arr_size
                        else:
                            # 不同serial_number,将之前的数据添加到列表
                            pending_merge_gyro.acc_data = np.array(pending_merge_acc.acc_data)  # type: ignore
                            gyro_data_list.append(pending_merge_acc)
                            pending_merge_gyro = gyro
                    else:
                        # 第一个数据,暂存
                        pending_merge_gyro = gyro

                elif data_type == "15":  # RAW_PPG_GREEN
                    ppg_g = PPG_Raw_Data.from_bytes(data_bytes, rawdata_v2, unix_timestamp)
                    # 检查是否需要与上一个数据合并
                    if pending_merge_ppg_g is not None:
                        if pending_merge_ppg_g.serial_number == ppg_g.serial_number:
                            pending_merge_ppg_g.ppg_data += ppg_g.ppg_data
                            pending_merge_ppg_g.arr_size += ppg_g.arr_size
                        else:
                            # 不同serial_number,将之前的数据添加到列表
                            pending_merge_ppg_g.ppg_data = np.array(pending_merge_ppg_g.ppg_data) - 1000_000  # type: ignore
                            ppg_g_data_list.append(pending_merge_ppg_g)
                            pending_merge_ppg_g = ppg_g
                    else:
                        # 第一个数据,暂存
                        pending_merge_ppg_g = ppg_g

                elif data_type == "16":  # RAW_PPG_RED
                    ppg_r = PPG_Raw_Data.from_bytes(data_bytes, rawdata_v2, unix_timestamp)
                    # 检查是否需要与上一个数据合并
                    if pending_merge_ppg_r is not None:
                        if pending_merge_ppg_r.serial_number == ppg_r.serial_number:
                            pending_merge_ppg_r.ppg_data += ppg_r.ppg_data
                            pending_merge_ppg_r.arr_size += ppg_r.arr_size
                        else:
                            # 不同serial_number,将之前的数据添加到列表
                            pending_merge_ppg_r.ppg_data = np.array(pending_merge_ppg_r.ppg_data) - 1000_000  # type: ignore
                            ppg_r_data_list.append(pending_merge_ppg_r)
                            pending_merge_ppg_r = ppg_r
                    else:
                        # 第一个数据,暂存
                        pending_merge_ppg_r = ppg_r

                elif data_type == "17":  # RAW_PPG_IR
                    ppg_ir = PPG_Raw_Data.from_bytes(data_bytes, rawdata_v2, unix_timestamp)
                    # 检查是否需要与上一个数据合并
                    if pending_merge_ppg_ir is not None:
                        if pending_merge_ppg_ir.serial_number == ppg_ir.serial_number:
                            pending_merge_ppg_ir.ppg_data += ppg_ir.ppg_data
                            pending_merge_ppg_ir.arr_size += ppg_ir.arr_size
                        else:
                            # 不同serial_number,将之前的数据添加到列表
                            pending_merge_ppg_ir.ppg_data = np.array(pending_merge_ppg_ir.ppg_data) - 1000_000  # type: ignore
                            ppg_ir_data_list.append(pending_merge_ppg_ir)
                            pending_merge_ppg_ir = ppg_ir
                    else:
                        # 第一个数据,暂存
                        pending_merge_ppg_ir = ppg_ir

                elif data_type == "26":  # RAW_PPG_RED_IR
                    ppg_r_ir = PPG_Raw_Data.from_bytes(data_bytes, rawdata_v2, unix_timestamp)
                    # 检查是否需要与上一个数据合并
                    if pending_merge_ppg_r_ir is not None:
                        if pending_merge_ppg_r_ir.serial_number == ppg_r_ir.serial_number:
                            pending_merge_ppg_r_ir.ppg_data += ppg_r_ir.ppg_data
                            pending_merge_ppg_r_ir.arr_size += ppg_r_ir.arr_size
                        else:
                            # 不同serial_number,将之前的数据添加到列表
                            pending_merge_ppg_r_ir.ppg_data = np.array(pending_merge_ppg_r_ir.ppg_data) - 1000_000  # type: ignore
                            ppg_r_ir_data_list.append(pending_merge_ppg_r_ir)
                            pending_merge_ppg_r_ir = ppg_r_ir
                    else:
                        # 第一个数据,暂存
                        pending_merge_ppg_r_ir = ppg_r_ir
                elif  data_type == "69" : # MOTION_INFO 运动识别
                    data = MotionRecognition.from_bytes(data_bytes,unix_timestamp=unix_timestamp,offset = 149)
                    motion_recognition_list.append(data)

                elif data_type == "71":  # WEAR_INFO
                    wear_info = WearInfo.from_bytes(data_bytes, rawdata_v2, unix_timestamp)
                    wear_info_list.append(wear_info)

                elif data_type == "81":  # TYHX_DATA
                    data = TYHX_PPG_Data.from_bytes(data_bytes, unix_timestamp=unix_timestamp)
                    TYHX_data_list.append(data)
                elif data_type == "82":  # TYHX_AGC_Data
                    if is_ring: # 戒指设备
                        data = TYHX_3697_Data.from_bytes(data_bytes, unix_timestamp=unix_timestamp)
                        TYHX_3697_data_list.append(data)
                    else:    
                        data = TYHX_AGC_Data.from_bytes(data_bytes, unix_timestamp=unix_timestamp)
                        TYHX_agc_data_list.append(data)

                elif data_type == "91":  # PSP_PPG_FIFO
                    data = PSP_PPG_FIFO.from_bytes(data_bytes, rawdata_v2, unix_timestamp=unix_timestamp)
                    psp_fifo_list.append(data)

            # 查找包含 JSON 格式的行
            elif line.startswith('{') and line.endswith('}'):
                try:
                    data = json.loads(line)
                    # print(f"Parsing metadata line: {line} {data}")
                    
                    # 分类处理不同类型的数据
                    if 'label' in data and 'timestamp' in data:
                        data['unix_timestamp'] = last_unix_timestamp
                        # print(f"Found label data in metadata {data}.")
                        metadata['labels'].append(data)
                    elif 'startTime' in data:
                        metadata['start_time'] = data['startTime']
                    elif 'device' in data:
                        metadata['device'] = data
                    elif 'reference' in data:
                        metadata['reference'] = data
                    elif 'phone' in data:
                        metadata['phone'] = data
                    elif 'app version' in data:
                        metadata['app_version'] = data['app version']
                    elif 'user_name' in data:
                        metadata['user_info'] = data
                    elif ' city ' in data or 'city' in data:
                        metadata['weather'] = data
                    elif 'data_type' in data:
                        metadata['data_type'] = data
                    elif 'sensor' in data:
                        metadata['sensor'] = data.get('sensor')
                    elif 'algorithm_info' in data:
                        metadata['algorithm_info'] = data.get('algorithm_info')
                except json.JSONDecodeError:
                        continue
                

    # 添加最后一个pending的数据
    if pending_merge_acc is not None:
        pending_merge_acc.acc_data = np.array(pending_merge_acc.acc_data)  # type: ignore
        acc_data_list.append(pending_merge_acc)

    if pending_merge_gyro is not None:
        pending_merge_gyro.acc_data = np.array(pending_merge_gyro.acc_data)  # type: ignore
        gyro_data_list.append(pending_merge_gyro)

    if pending_merge_ppg_g is not None:
        pending_merge_ppg_g.ppg_data = np.array(pending_merge_ppg_g.ppg_data) - 1000_000  # type: ignore
        ppg_g_data_list.append(pending_merge_ppg_g)

    if pending_merge_ppg_r is not None:
        pending_merge_ppg_r.ppg_data = np.array(pending_merge_ppg_r.ppg_data) - 1000_000  # type: ignore
        ppg_r_data_list.append(pending_merge_ppg_r)

    if pending_merge_ppg_ir is not None:
        pending_merge_ppg_ir.ppg_data = np.array(pending_merge_ppg_ir.ppg_data) - 1000_000  # type: ignore
        ppg_ir_data_list.append(pending_merge_ppg_ir)

    # 创建 DataFrame 并添加到结果字典
    if base_info_list:
        base_info_df = pd.DataFrame(base_info_list)
        result["base_info_df"] = base_info_df

    if wear_info_list:
        wear_info_df = pd.DataFrame(wear_info_list)
        result["wear_info_df"] = wear_info_df

    if acc_data_list:
        acc_df = pd.DataFrame(acc_data_list)
        if "unix_timestamp" in acc_df.columns and "ms" in acc_df.columns:
            acc_df["unix_timestamp_ms"] = acc_df["unix_timestamp"]  + acc_df["ms"]/1000
        result["acc_df"] = acc_df

    if gyro_data_list:
        gyro_df = pd.DataFrame(gyro_data_list)
        if "unix_timestamp" in gyro_df.columns and "ms" in gyro_df.columns:
            gyro_df["unix_timestamp_ms"] = gyro_df["unix_timestamp"]  + gyro_df["ms"]/1000
        gyro_df.rename(columns={'acc_data': 'gyro_data'}, inplace=True)    
        result["gyro_df"] = gyro_df

    if ppg_g_data_list:
        ppg_g_df = pd.DataFrame(ppg_g_data_list)
        if "unix_timestamp" in ppg_g_df.columns and "ms" in ppg_g_df.columns:
            ppg_g_df["unix_timestamp_ms"] = ppg_g_df["unix_timestamp"]  + ppg_g_df["ms"]/1000
        ppg_g_df = process_ppg_dataframe(ppg_g_df)
        result["ppg_g_df"] = ppg_g_df

    if ppg_r_data_list:
        ppg_r_df = pd.DataFrame(ppg_r_data_list)
        if "unix_timestamp" in ppg_r_df.columns and "ms" in ppg_r_df.columns:
            ppg_r_df["unix_timestamp_ms"] = ppg_r_df["unix_timestamp"]  + ppg_r_df["ms"]/1000
        ppg_r_df = process_ppg_dataframe(ppg_r_df,1) # 红光单通道
        result["ppg_r_df"] = ppg_r_df

    if ppg_ir_data_list:
        ppg_ir_df = pd.DataFrame(ppg_ir_data_list)
        if "unix_timestamp" in ppg_ir_df.columns and "ms" in ppg_ir_df.columns:
            ppg_ir_df["unix_timestamp_ms"] = ppg_ir_df["unix_timestamp"] + ppg_ir_df["ms"]/1000
        ppg_ir_df = process_ppg_dataframe(ppg_ir_df,1)  # 红外单通道
        result["ppg_ir_df"] = ppg_ir_df

    if ppg_r_ir_data_list:
        ppg_r_ir_df = pd.DataFrame(ppg_r_ir_data_list)
        if "unix_timestamp" in ppg_r_ir_df.columns and "ms" in ppg_r_ir_df.columns:
            ppg_r_ir_df["unix_timestamp_ms"] = ppg_r_ir_df["unix_timestamp"] + ppg_r_ir_df["ms"]/1000
        ppg_r_ir_df = process_ppg_dataframe(ppg_r_ir_df,1)  # 红外红光单通道
        ppg_r_ir_df['channel_num'] = 1 
        result["ppg_r_ir_df"] = ppg_r_ir_df

    if TYHX_data_list:
        TYHX_data_df = pd.DataFrame(TYHX_data_list)
        result["TYHX_data_df"] = TYHX_data_df
    if TYHX_agc_data_list:
        TYHX_agc_data_df = pd.DataFrame(TYHX_agc_data_list)
        result["TYHX_agc_data_df"] = TYHX_agc_data_df
    if TYHX_3697_data_list:
        TYHX_3697_data_df = pd.DataFrame(TYHX_3697_data_list)
        result["TYHX_3697_data_df"] = TYHX_3697_data_df

    if motion_recognition_list:
        motion_recognition_df = pd.DataFrame(motion_recognition_list)
        result["motion_recognition_df"] = motion_recognition_df
    if psp_fifo_list:
        psp_fifo_df = pd.DataFrame(psp_fifo_list)
        result["psp_fifo_df"] = psp_fifo_df

    result["metadata"] = metadata
    result["data_types"] = data_type_dict

    return result


def expand_imu_data(df, data_column='acc_data', min_sr=48.0):
    """
    通用的 IMU 数据展开函数,将压缩的传感器数据展开为时间序列
    
    Parameters:
    -----------
    df : pd.DataFrame
        包含 'unix_timestamp' 和指定数据列的 DataFrame
    data_column : str
        传感器数据列名,如 'acc_data', 'gyro_data' 等,默认 'acc_data'
    min_sr : float
        最小采样率,默认 48.0 Hz
    
    Returns:
    --------
    pd.DataFrame
        展开后的 DataFrame,包含 'unix_timestamp', 'x', 'y', 'z' 列
    """
    if df is None or df.empty or data_column not in df.columns:
        return pd.DataFrame(columns=['unix_timestamp', 'x', 'y', 'z'])
    
    MAX_SEC_PER_POINT = 1.0 / min_sr 
    
    all_timestamps = []
    all_sensor_data = []
    
    df = df.sort_values('unix_timestamp')
    rows = list(df[['unix_timestamp', data_column]].itertuples(index=False, name=None))
    
    prev_ts = None
    for current_ts, sensor_data in rows:
        if sensor_data is None or len(sensor_data) == 0:
            continue
            
        n_points = len(sensor_data)
        
        # 判断是否断档的阈值
        max_duration = n_points * MAX_SEC_PER_POINT
        
        if prev_ts is None:
            # 第一帧:默认按点数/50Hz倒推
            duration = n_points * 0.02
            start_time = current_ts - duration
        else:
            delta_t = current_ts - prev_ts
            
            # 只有当间隔大得离谱时,才截断
            if delta_t > max_duration:
                # 断档:倒推
                duration = n_points * 0.02 
                start_time = current_ts - duration
            else:
                # 正常连接 (包括 100Hz 的情况)
                duration = delta_t
                start_time = prev_ts
        
        # 生成时间戳
        step = duration / n_points
        timestamps = start_time + step * (np.arange(n_points) + 1)
        
        all_timestamps.append(timestamps)
        all_sensor_data.append(sensor_data)
        prev_ts = current_ts

    if not all_sensor_data:
        return pd.DataFrame(columns=['unix_timestamp', 'x', 'y', 'z'])
        
    final_df = pd.DataFrame(np.concatenate(all_sensor_data), columns=['x', 'y', 'z'])
    final_df['unix_timestamp'] = np.concatenate(all_timestamps)
    return final_df


def expand_acc_data(acc_df, min_sr=48.0):
    """
    展开加速度数据,将压缩的ACC数据展开为时间序列
    (向后兼容的包装函数,调用 expand_imu_data)
    
    Parameters:
    -----------
    acc_df : pd.DataFrame
        包含 'unix_timestamp' 和 'acc_data' 列的 DataFrame
    min_sr : float
        最小采样率,默认 48.0 Hz
    
    Returns:
    --------
    pd.DataFrame
        展开后的 DataFrame,包含 'unix_timestamp', 'x', 'y', 'z' 列
    """
    return expand_imu_data(acc_df, data_column='acc_data', min_sr=min_sr)

def expand_gyro_data(gyro_df, min_sr=48.0):
    return expand_imu_data(gyro_df, data_column='gyro_data', min_sr=min_sr)

def expand_ppg_data(ppg_df, data_col='ppg_data'):
    """
    展开 PPG 数据,将压缩的PPG数据展开为时间序列
    
    Parameters:
    -----------
    ppg_df : pd.DataFrame
        包含 'unix_timestamp' 和指定数据列的 DataFrame
    data_col : str
        PPG 数据列名,默认 'ppg_data'
    
    Returns:
    --------
    pd.DataFrame
        展开后的 DataFrame,包含 'unix_timestamp' 和 'ppg_value' 列
    """
    all_timestamps = []
    all_values = []
    
    # 排序
    ppg_df = ppg_df.sort_values('unix_timestamp')
    rows = list(ppg_df[['unix_timestamp', data_col]].itertuples(index=False, name=None))
    
    for ts, data_array in rows:
        if data_array is None or len(data_array) == 0:
            continue
            
        n_points = len(data_array)
        
        # 假设这一包数据填满过去的一秒
        # 起点: ts - 1.0, 终点: ts
        step = 1.0 / n_points
        timestamps = (float(ts) - 1.0) + step * (np.arange(n_points) + 1)
        
        all_timestamps.append(timestamps)
        all_values.append(data_array)
    
    if not all_values:
        return pd.DataFrame(columns=['unix_timestamp', data_col])
        
    final_df = pd.DataFrame({
        'unix_timestamp': np.concatenate(all_timestamps),
        data_col: np.concatenate(all_values)
    })
    
    return final_df


def merge_sensor_data(acc_df, ppg_g_df, ppg_ir_df, ppg_r_df, wear_info_df):
    """
    合并传感器数据(处理重复时间戳、合并多个传感器数据)
    
    Parameters:
    -----------
    acc_df : pd.DataFrame
        加速度数据
    ppg_g_df : pd.DataFrame
        绿光 PPG 数据
    ppg_ir_df : pd.DataFrame
        红外光 PPG 数据
    ppg_r_df : pd.DataFrame
        红光 PPG 数据
    wear_info_df : pd.DataFrame
        佩戴信息数据
    
    Returns:
    --------
    tuple
        (combined_ppg_df, wear_info_df, processed_acc_df, processed_ppg_g_df, 
         processed_ppg_ir_df, processed_ppg_r_df)
    """
    # 处理 processed_acc_df
    processed_acc_df = acc_df[['unix_timestamp', 'acc_data']].copy()  
    if processed_acc_df['unix_timestamp'].duplicated().any():
        print(f"processed_acc_df 发现 {processed_acc_df['unix_timestamp'].duplicated().sum()} 条重复的 unix_timestamp, 正在合并...")
        processed_acc_df = processed_acc_df.groupby('unix_timestamp', as_index=False).agg({
            'acc_data': lambda x: np.concatenate([arr for arr in x if isinstance(arr, np.ndarray)]) if any(isinstance(arr, np.ndarray) for arr in x) else None,
        })
        if "unix_timestamp" in processed_acc_df.columns and "ms" in processed_acc_df.columns:
            processed_acc_df["unix_timestamp_ms"] = processed_acc_df["unix_timestamp"] * 1000 + processed_acc_df["ms"]
        print(f"processed_acc_df 合并后记录数: {len(processed_acc_df)}")
    processed_acc_df['acc_size'] = processed_acc_df['acc_data'].apply(lambda x: len(x) if isinstance(x, np.ndarray) else 0)

    # 处理 processed_ppg_g_df - 动态识别通道数
    ppg_g_channel_cols = [col for col in ppg_g_df.columns if col.startswith('ppg_data_')]
    if ppg_g_channel_cols:
        select_cols = ['unix_timestamp', 'data', 'channel_num'] + ppg_g_channel_cols
    else:
        select_cols = ['unix_timestamp', 'data', 'ppg_data'] if 'ppg_data' in ppg_g_df.columns else ['unix_timestamp', 'data']
    
    processed_ppg_g_df = ppg_g_df[select_cols].copy()
    
    # 重命名通道列
    rename_map = {col: col.replace('ppg_data_', 'ppg_g_data_') for col in ppg_g_channel_cols}
    if 'ppg_data' in processed_ppg_g_df.columns:
        rename_map['ppg_data'] = 'ppg_g_data_0'
    processed_ppg_g_df = processed_ppg_g_df.rename(columns=rename_map)
    
    if (processed_ppg_g_df is not None and 
        not processed_ppg_g_df.empty and 
        'unix_timestamp' in processed_ppg_g_df.columns):
        if processed_ppg_g_df['unix_timestamp'].duplicated().any():
            print(f"processed_ppg_g_df 发现 {processed_ppg_g_df['unix_timestamp'].duplicated().sum()} 条重复的 unix_timestamp, 正在合并...")
            # 构建聚合字典
            agg_dict = {'data': "last", 'channel_num': 'max'}
            for col in processed_ppg_g_df.columns:
                if col.startswith('ppg_g_data_'):
                    agg_dict[col] = lambda x: np.concatenate([arr for arr in x if isinstance(arr, np.ndarray)]) if any(isinstance(arr, np.ndarray) for arr in x) else None # type: ignore
            processed_ppg_g_df = processed_ppg_g_df.groupby('unix_timestamp', as_index=False).agg(agg_dict)
            print(f"processed_ppg_g_df 合并后记录数: {len(processed_ppg_g_df)}")
    else:
        print("processed_ppg_g_df 为空或缺少 unix_timestamp 列")
    
    # 计算总大小
    size_cols = [col for col in processed_ppg_g_df.columns if col.startswith('ppg_g_data_')]
    if size_cols:
        processed_ppg_g_df['green_size'] = processed_ppg_g_df[size_cols[0]].apply(lambda x: len(x) if isinstance(x, np.ndarray) else 0)
    else:
        processed_ppg_g_df['green_size'] = 0

    # 处理 processed_ppg_ir_df - 动态识别通道数
    ppg_ir_channel_cols = [col for col in ppg_ir_df.columns if col.startswith('ppg_data_')]
    if ppg_ir_channel_cols:
        select_cols = ['unix_timestamp', 'data', 'channel_num'] + ppg_ir_channel_cols
    else:
        select_cols = ['unix_timestamp', 'data', 'ppg_data'] if 'ppg_data' in ppg_ir_df.columns else ['unix_timestamp', 'data']
    
    processed_ppg_ir_df = ppg_ir_df[select_cols].copy()
    
    # 重命名通道列
    rename_map = {col: col.replace('ppg_data_', 'ppg_ir_data_') for col in ppg_ir_channel_cols}
    if 'ppg_data' in processed_ppg_ir_df.columns:
        rename_map['ppg_data'] = 'ppg_ir_data_0'
    processed_ppg_ir_df = processed_ppg_ir_df.rename(columns=rename_map)
    
    if (processed_ppg_ir_df is not None and
         not processed_ppg_ir_df.empty and 
         'unix_timestamp' in processed_ppg_ir_df.columns):
        if processed_ppg_ir_df['unix_timestamp'].duplicated().any():
            print(f"processed_ppg_ir_df 发现 {processed_ppg_ir_df['unix_timestamp'].duplicated().sum()} 条重复的 unix_timestamp, 正在合并...")
            # 构建聚合字典
            agg_dict = {'data': "last", 'channel_num': 'max'}
            for col in processed_ppg_ir_df.columns:
                if col.startswith('ppg_ir_data_'):
                    agg_dict[col] = lambda x: np.concatenate([arr for arr in x if isinstance(arr, np.ndarray)]) if any(isinstance(arr, np.ndarray) for arr in x) else None # type: ignore
            processed_ppg_ir_df = processed_ppg_ir_df.groupby('unix_timestamp', as_index=False).agg(agg_dict)
            print(f"processed_ppg_ir_df 合并后记录数: {len(processed_ppg_ir_df)}")
    else:
        print("processed_ppg_ir_df 为空或缺少 unix_timestamp 列")
    
    # 计算总大小
    size_cols = [col for col in processed_ppg_ir_df.columns if col.startswith('ppg_ir_data_')]
    if size_cols:
        processed_ppg_ir_df['ir_size'] = processed_ppg_ir_df[size_cols[0]].apply(lambda x: len(x) if isinstance(x, np.ndarray) else 0)
    else:
        processed_ppg_ir_df['ir_size'] = 0

    # 处理 processed_ppg_r_df - 动态识别通道数
    ppg_r_channel_cols = [col for col in ppg_r_df.columns if col.startswith('ppg_data_')]
    if ppg_r_channel_cols:
        select_cols = ['unix_timestamp', 'data', 'channel_num'] + ppg_r_channel_cols
    else:
        select_cols = ['unix_timestamp', 'data', 'ppg_data'] if 'ppg_data' in ppg_r_df.columns else ['unix_timestamp', 'data']
    
    processed_ppg_r_df = ppg_r_df[select_cols].copy()
    
    # 重命名通道列
    rename_map = {col: col.replace('ppg_data_', 'ppg_r_data_') for col in ppg_r_channel_cols}
    if 'ppg_data' in processed_ppg_r_df.columns:
        rename_map['ppg_data'] = 'ppg_r_data_0'
    processed_ppg_r_df = processed_ppg_r_df.rename(columns=rename_map)
    
    if (processed_ppg_r_df is not None and
         not processed_ppg_r_df.empty and 
         'unix_timestamp' in processed_ppg_r_df.columns):   
        if processed_ppg_r_df['unix_timestamp'].duplicated().any():
            print(f"processed_ppg_r_df 发现 {processed_ppg_r_df['unix_timestamp'].duplicated().sum()} 条重复的 unix_timestamp, 正在合并...")
            # 构建聚合字典
            agg_dict = {'data': "last", 'channel_num': 'max'}
            for col in processed_ppg_r_df.columns:
                if col.startswith('ppg_r_data_'):
                    agg_dict[col] = lambda x: np.concatenate([arr for arr in x if isinstance(arr, np.ndarray)]) if any(isinstance(arr, np.ndarray) for arr in x) else None # type: ignore
            processed_ppg_r_df = processed_ppg_r_df.groupby('unix_timestamp', as_index=False).agg(agg_dict)
            print(f"processed_ppg_r_df 合并后记录数: {len(processed_ppg_r_df)}")
    else:
        print("processed_ppg_r_df 为空或缺少 unix_timestamp 列")
    
    # 计算总大小
    size_cols = [col for col in processed_ppg_r_df.columns if col.startswith('ppg_r_data_')]
    if size_cols:
        processed_ppg_r_df['red_size'] = processed_ppg_r_df[size_cols[0]].apply(lambda x: len(x) if isinstance(x, np.ndarray) else 0)
    else:
        processed_ppg_r_df['red_size'] = 0

    # 处理 wear_info_df
    if (wear_info_df is not None and
        not wear_info_df.empty and
        'unix_timestamp' in wear_info_df.columns):
        if wear_info_df['unix_timestamp'].duplicated().any():
            print(f"wear_info_df 发现 {wear_info_df['unix_timestamp'].duplicated().sum()} 条重复的 unix_timestamp, 正在合并...")
            wear_info_df = wear_info_df.groupby('unix_timestamp', as_index=False).agg({
                'wear_flag': 'last',
                'error_no': 'last',
                'wear_ir_result': 'last',
                'confusion': 'last',
                'peak_cnt': 'last',
                'wear_rr_hr': 'last',
                'wear_acc_std': 'last',
                'return_type': 'last',
                'green_temp_flag_encode': 'last',
                'init_timer': 'last',
                'amb_std': 'last',
                'ppg_dc_value': 'last',
                'state': 'last',
                'imu_6d_state': 'last',
                'ppg_g_current': 'last',
                'ppg_g_idac': 'last',
                'ppg_ir_value': 'last'
            })
            print(f"wear_info_df 合并后记录数: {len(wear_info_df)}")

    # 合并数据
    processed_ppg_ir_df_for_merge = processed_ppg_ir_df.drop(columns=['data'])
    processed_ppg_r_df_for_merge = processed_ppg_r_df.drop(columns=['data']) if (isinstance(processed_ppg_r_df, pd.DataFrame) and 'data' in processed_ppg_r_df.columns) else (processed_ppg_r_df if isinstance(processed_ppg_r_df, pd.DataFrame) else pd.DataFrame())
    
    combined_ppg_df = processed_acc_df.merge(processed_ppg_g_df, on='unix_timestamp', how='outer')
    combined_ppg_df = combined_ppg_df.merge(processed_ppg_ir_df_for_merge, on='unix_timestamp', how='outer')
    
    if not processed_ppg_r_df_for_merge.empty:
        combined_ppg_df = combined_ppg_df.merge(processed_ppg_r_df_for_merge, on='unix_timestamp', how='outer')
    else:
        combined_ppg_df['ppg_r_data'] = np.nan
        combined_ppg_df['red_size'] = 0
    
    # 填充缺失值
    combined_ppg_df['acc_size'] = combined_ppg_df['acc_size'].fillna(0).astype(int)
    combined_ppg_df['green_size'] = combined_ppg_df['green_size'].fillna(0).astype(int)
    combined_ppg_df['ir_size'] = combined_ppg_df['ir_size'].fillna(0).astype(int)
    if 'red_size' in combined_ppg_df.columns:
        combined_ppg_df['red_size'] = combined_ppg_df['red_size'].fillna(0).astype(int)
    
    combined_ppg_df['data'] = combined_ppg_df['data'].apply(
        lambda x: x if isinstance(x, (list, np.ndarray)) else np.array([0, 0, 0, 0, 0])
    )
    
    # 填充所有通道数据列
    for col in combined_ppg_df.columns:
        if col.startswith(('ppg_g_data_', 'ppg_ir_data_', 'ppg_r_data_')):
            combined_ppg_df[col] = combined_ppg_df[col].apply(
                lambda x: x if isinstance(x, (list, np.ndarray)) else np.array([])
            )

    combined_ppg_df['acc_data'] = combined_ppg_df['acc_data'].ffill()
    combined_ppg_df['acc_data'] = combined_ppg_df['acc_data'].bfill()
    combined_ppg_df['acc_data'] = combined_ppg_df['acc_data'].apply(
        lambda x: x if isinstance(x, np.ndarray) else np.array([]).reshape(0, 3)
    )
    
    return combined_ppg_df, wear_info_df, processed_acc_df, processed_ppg_g_df, processed_ppg_ir_df, processed_ppg_r_df


def expand_sensor_data(processed_acc_df, processed_ppg_g_df, processed_ppg_ir_df, processed_ppg_r_df):
    """
    展开传感器数据(将压缩的传感器数据展开为时间序列)
    
    Parameters:
    -----------
    processed_acc_df : pd.DataFrame
        处理后的加速度数据(包含 acc_data 列)
    processed_ppg_g_df : pd.DataFrame
        处理后的绿光 PPG 数据(包含 ppg_g_data_* 列)
    processed_ppg_ir_df : pd.DataFrame
        处理后的红外光 PPG 数据(包含 ppg_ir_data_* 列)
    processed_ppg_r_df : pd.DataFrame
        处理后的红光 PPG 数据(包含 ppg_r_data_* 列)
    
    Returns:
    --------
    tuple
        (expanded_acc_df, expanded_ppg_g_df, expanded_ppg_ir_df, expanded_ppg_r_df)
    """

    def _pick_ppg_col(df: pd.DataFrame, prefix: str, fallback: str):
        """选择首选的 PPG 数据列,兼容单/多通道命名。"""
        if df is None or df.empty:
            return None
        if fallback in df.columns:
            return fallback
        prefixed_cols = [c for c in df.columns if c.startswith(prefix)]
        return prefixed_cols[0] if prefixed_cols else None

    expanded_acc_df = expand_acc_data(processed_acc_df) if processed_acc_df is not None and not processed_acc_df.empty else pd.DataFrame()

    g_col = _pick_ppg_col(processed_ppg_g_df, 'ppg_g_data_', 'ppg_g_data')
    expanded_ppg_g_df = expand_ppg_data(processed_ppg_g_df, data_col=g_col) if g_col else pd.DataFrame()
    if not expanded_ppg_g_df.empty and g_col and g_col in expanded_ppg_g_df.columns:
        expanded_ppg_g_df = expanded_ppg_g_df.rename(columns={g_col: 'ppg_value'})

    ir_col = _pick_ppg_col(processed_ppg_ir_df, 'ppg_ir_data_', 'ppg_ir_data')
    expanded_ppg_ir_df = expand_ppg_data(processed_ppg_ir_df, data_col=ir_col) if ir_col else pd.DataFrame()
    if not expanded_ppg_ir_df.empty and ir_col and ir_col in expanded_ppg_ir_df.columns:
        expanded_ppg_ir_df = expanded_ppg_ir_df.rename(columns={ir_col: 'ppg_value'})

    r_col = _pick_ppg_col(processed_ppg_r_df, 'ppg_r_data_', 'ppg_r_data')
    expanded_ppg_r_df = expand_ppg_data(processed_ppg_r_df, data_col=r_col) if r_col else pd.DataFrame()
    if not expanded_ppg_r_df.empty and r_col and r_col in expanded_ppg_r_df.columns:
        expanded_ppg_r_df = expanded_ppg_r_df.rename(columns={r_col: 'ppg_value'})
    
    return expanded_acc_df, expanded_ppg_g_df, expanded_ppg_ir_df, expanded_ppg_r_df


def process_and_merge_sensor_data(acc_df, ppg_g_df, ppg_ir_df, ppg_r_df, wear_info_df):
    """
    处理和合并传感器数据(向后兼容的包装函数)
    
    Parameters:
    -----------
    acc_df : pd.DataFrame
        加速度数据
    ppg_g_df : pd.DataFrame
        绿光 PPG 数据
    ppg_ir_df : pd.DataFrame
        红外光 PPG 数据
    ppg_r_df : pd.DataFrame
        红光 PPG 数据
    wear_info_df : pd.DataFrame
        佩戴信息数据
    
    Returns:
    --------
    tuple
        (combined_ppg_df, wear_info_df, expanded_acc_df, expanded_ppg_g_df, 
         expanded_ppg_ir_df, expanded_ppg_r_df)
    """
    # 合并数据
    combined_ppg_df, wear_info_df, processed_acc_df, processed_ppg_g_df, processed_ppg_ir_df, processed_ppg_r_df = merge_sensor_data(
        acc_df, ppg_g_df, ppg_ir_df, ppg_r_df, wear_info_df
    )
    
    # 展开数据
    expanded_acc_df, expanded_ppg_g_df, expanded_ppg_ir_df, expanded_ppg_r_df = expand_sensor_data(
        processed_acc_df, processed_ppg_g_df, processed_ppg_ir_df, processed_ppg_r_df
    )
    
    return combined_ppg_df, wear_info_df, expanded_acc_df, expanded_ppg_g_df, expanded_ppg_ir_df, expanded_ppg_r_df



def print_metadata(metadata):
    """
    格式化打印元数据
    
    参数:
        metadata: parse_labels_from_file 返回的元数据字典
    """
    print("\n" + "="*60)
    print("文件元数据信息")
    print("="*60)
    
    if metadata['start_time']:
        print(f"\n开始时间: {metadata['start_time']}")
    
    if metadata['device']:
        print(f"\n设备信息:")
        for key, value in metadata['device'].items():
            print(f"  {key}: {value}")
    
    if metadata['phone']:
        print(f"\n手机信息:")
        for key, value in metadata['phone'].items():
            print(f"  {key}: {value}")
    
    if metadata['app_version']:
        print(f"\n应用版本: {metadata['app_version']}")
    
    if metadata['user_info']:
        print(f"\n用户信息:")
        for key, value in metadata['user_info'].items():
            print(f"  {key}: {value}")
    
    if metadata['weather']:
        print(f"\n天气信息:")
        for key, value in metadata['weather'].items():
            print(f"  {key}: {value}")
    
    if metadata['data_type']:
        print(f"\n数据类型:")
        for key, value in metadata['data_type'].items():
            print(f"  {key}: {value}")
    
    if metadata['sensor']:
        print(f"\n传感器: {metadata['sensor']}")
    
    if metadata['algorithm_info']:
        print(f"\n算法信息: {metadata['algorithm_info']}")
    
    if metadata['labels']:
        print(f"\n标签数据 ({len(metadata['labels'])} 条):")
        for label in metadata['labels']:
            print(f"  {label.get('label', 'N/A')}: {label.get('timestamp', 'N/A')}")
    
    print("="*60)







def segment_by_labels(labels):
    """
    根据 Start 和 End 标签分隔时间段
    
    规则:
    - 一个 Start 匹配一个 End
    - 两个 Start 相连,取后一个
    - 两个 End 相连,取前一个
    
    参数:
        labels: 标签列表,每个标签是包含 'label' 和 'timestamp' 的字典
    
    返回:
        list: 分段列表,每段包含 segment_id, timestamp_start, timestamp_stop
    """
    if not labels:
        return []
    
    # 按时间戳排序标签
    sorted_labels = sorted(labels, key=lambda x: x.get('unix_timestamp', 0))
    
    segments = []
    segment_id = 1
    
    i = 0
    while i < len(sorted_labels):
        current = sorted_labels[i]
        
        # 查找 Start 标签
        if current.get('label', '').lower() == 'start':
            start_timestamp = current.get('timestamp')
            start_unix = current.get('unix_timestamp')
            # 检查是否有连续的 Start,如果有,取最后一个
            j = i + 1
            while j < len(sorted_labels) and sorted_labels[j].get('label', '').lower() == 'start':
                start_timestamp = sorted_labels[j].get('timestamp')
                start_unix = sorted_labels[j].get('unix_timestamp')
                i = j
                j += 1
            
            # 查找对应的 End 标签
            end_found = False
            for k in range(i + 1, len(sorted_labels)):
                if sorted_labels[k].get('label', '').lower() == 'end':
                    end_timestamp = sorted_labels[k].get('timestamp')
                    stop_unix = sorted_labels[k].get('unix_timestamp')
                    # 检查是否有连续的 End,如果有,取第一个
                    segments.append({
                        'segment_id': segment_id,
                        'start_ux': start_timestamp,
                        "stop_ux" : end_timestamp,
                        "start_unix": start_unix,
                        "stop_unix": stop_unix,
                    })
                    segment_id += 1
                    
                    # 跳过连续的 End 标签
                    m = k + 1
                    while m < len(sorted_labels) and sorted_labels[m].get('label', '').lower() == 'end':
                        m += 1
                    i = m - 1
                    end_found = True
                    break
            
            if not end_found:
                # 没有找到匹配的 End,记录未完成的段
                print(f"警告: Start 标签 '{start_timestamp}' 没有匹配的 End 标签")
        
        i += 1
    
    return segments




def print_segments(segments):
    """
    格式化打印分段信息
    
    参数:
        segments: segment_by_labels 返回的分段列表
    """
    if not segments:
        print("没有找到有效的分段")
        return
    
    print(f"\n{'='*80}")
    print(f"{'分段ID':^10} | {'开始时间':^20} | {'结束时间':^20} | {'持续时间(秒)':^10}")
    print(f"{'='*80}")
    
    for seg in segments:
        start_ts = seg['start_ux']
        stop_ts = seg['stop_ux']
        start_unix = seg['start_unix']
        stop_unix = seg['stop_unix']
        

        if start_unix and stop_unix:
            duration = stop_unix - start_unix
            print(f"{seg['segment_id']:^10} | {start_ts:^20} | {stop_ts:^20} | {duration:^10}")
        else:
            print(f"{seg['segment_id']:^10} | {start_ts:^20} | {stop_ts:^20} | {'N/A':^10}")
    
    print(f"{'='*80}")
    print(f"总共 {len(segments)} 个分段\n")
