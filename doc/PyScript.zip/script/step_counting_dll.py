import ctypes
import numpy as np
import gc

# 定义结构体
class AccSensorDataForEmbT(ctypes.Structure):
    _fields_ = [
        ("x_axis", ctypes.c_int16),     # int16_t
        ("y_axis", ctypes.c_int16),     # int16_t
        ("z_axis", ctypes.c_int16),     # int16_t
        ("xyz_resultant", ctypes.c_uint16) # uint16_t
    ]

class StepCountAlgVersion(ctypes.Structure):
    _fields_ = [
        ("main_version", ctypes.c_uint8),
        ("sub_version", ctypes.c_uint8)
    ]

def my_print_callback(message):
    print(f"{message}", end='')

class StepCountingDLL:
    def __init__(self, dll_path):
        self.dll_path = dll_path
        self.dll = ctypes.CDLL(dll_path)
        self.dll_handle = None  # 保存DLL句柄用于释放
        
        # 设置函数签名
        self.dll.creek_step_count_alg_process_for_emb.argtypes = [
            ctypes.POINTER(AccSensorDataForEmbT), # acc_sensor_data_for_emb_t acc_data_buf[] (指针)
            ctypes.c_uint8                       # uint8_t size
        ]
        self.dll.creek_step_count_alg_process_for_emb.restype = ctypes.c_uint8    # uint8_t
        
        self.dll.get_step_count_alg_version.restype = StepCountAlgVersion
        self.dll.clear_stepping_cache.argtypes = []
        self.dll.clear_stepping_cache.restype = None
        
        # 获取DLL句柄(用于释放)
        try:
            self.dll_handle = self.dll._handle
        except AttributeError:
            # 在某些Python版本中可能没有_handle属性
            self.dll_handle = None
        
        # 初始化标志
        self.initialized = True  # 假设不需要初始化,直接可用
        self._dll_released = False  # 标记是否已释放
        
        # 回调函数引用(防止垃圾回收)
        self._print_callback = None

        self.set_print_callback(my_print_callback)
    
    def __enter__(self):
        """上下文管理器入口"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        # print("Releasing StepCountingDLL resources...")
        self.close()
        return False
    
    def set_print_callback(self, callback_func):
        """
        设置打印回调函数
        
        Args:
            callback_func: Python函数,接受一个字符串参数(const char*)
        """
        if callback_func is None:
            # 清除回调(如果DLL支持)
            self._print_callback = None
        else:
            # 这里假设DLL没有设置回调的功能,如果有,可以添加
            self._print_callback = callback_func
    
    def process(self, acc_data):
        """
        处理一包加速度数据,返回步数
        
        Args:
            acc_data: list of tuples [(x, y, z), ...]
        
        Returns:
            int: 步数
        """
        if not isinstance(acc_data, list):
            raise ValueError("acc_data 必须是列表")
        
        if len(acc_data) == 0:
            raise ValueError("acc_data 不能为空")
        
        # 获取数据大小
        current_chunk_size = len(acc_data)
        if current_chunk_size > 255:
            raise ValueError("acc_data 长度不能超过255")
        
        # 创建 ctypes 结构体数组
        AccDataArrayType = AccSensorDataForEmbT * current_chunk_size
        c_struct_array = AccDataArrayType()
        
        # 填充结构体数组
        for j in range(current_chunk_size):
            x, y, z = acc_data[j]
            # 计算 xyz_resultant (合成的加速度值)
            xyz_resultant = int(np.sqrt(x**2 + y**2 + z**2))
            
            c_struct_array[j].x_axis = ctypes.c_int16(x)
            c_struct_array[j].y_axis = ctypes.c_int16(y)
            c_struct_array[j].z_axis = ctypes.c_int16(z)
            c_struct_array[j].xyz_resultant = ctypes.c_uint16(xyz_resultant)
        
        # 调用 DLL 函数
        result = self.dll.creek_step_count_alg_process_for_emb(c_struct_array, ctypes.c_uint8(current_chunk_size))
        
        return result
    
    def get_version(self):
        """获取算法版本"""
        return self.dll.get_step_count_alg_version()
    
    def clear_cache(self):
        """清除步数缓存"""
        self.dll.clear_stepping_cache()
    
    def close(self):
        """清理资源 - 手动释放DLL"""
        if not hasattr(self, '_dll_released') or not self._dll_released:
            try:
                # 在Windows上手动释放DLL
                if hasattr(self, 'dll_handle') and self.dll_handle is not None:
                    # 加载kernel32.dll来释放库
                    kernel32 = ctypes.windll.kernel32
                    kernel32.FreeLibrary.argtypes = [ctypes.c_void_p]
                    kernel32.FreeLibrary(self.dll_handle)
                    # print("DLL已手动释放")
                else:
                    print("DLL handle is unavailable; use garbage collection to release it.")
                
                # 删除DLL对象的引用
                if hasattr(self, 'dll'):
                    del self.dll
                
                # 强制垃圾回收
                gc.collect()
                
                self._dll_released = True
                # print("StepCountingDLL资源已清理")
                
            except Exception as e:
                print(f"Error releasing DLL: {e}")
                # 即使出错也标记为已释放,避免重复释放
                self._dll_released = True
    
    def __del__(self):
        """析构函数 - 确保资源被释放"""
        self.close()

if __name__ == "__main__":
    dll_path = r"alg_step_count/_creek_stepping_algo3.dll"
    try:
        # 使用上下文管理器自动管理DLL资源
        with StepCountingDLL(dll_path) as dll:
            # 获取版本
            version = dll.get_version()
            print(f"Step Counting Algorithm Version: {version.main_version}.{version.sub_version}")
            
            # 清除缓存
            dll.clear_cache()
            print("Cache cleared.")
            
            # 示例数据：模拟一秒的加速度数据(25Hz采样率)
            sample_acc_data = [
                (100, 200, 900), (105, 195, 905), (110, 190, 910),
                (115, 185, 915), (120, 180, 920), (125, 175, 925),
                (130, 170, 930), (135, 165, 935), (140, 160, 940),
                (145, 155, 945), (150, 150, 950), (155, 145, 955),
                (160, 140, 960), (165, 135, 965), (170, 130, 970),
                (175, 125, 975), (180, 120, 980), (185, 115, 985),
                (190, 110, 990), (195, 105, 995), (200, 100, 1000),
                (205, 95, 1005), (210, 90, 1010), (215, 85, 1015),
                (220, 80, 1020),
                            (100, 200, 900), (105, 195, 905), (110, 190, 910),
                (115, 185, 915), (120, 180, 920), (125, 175, 925),
                (130, 170, 930), (135, 165, 935), (140, 160, 940),
                (145, 155, 945), (150, 150, 950), (155, 145, 955),
                (160, 140, 960), (165, 135, 965), (170, 130, 970),
                (175, 125, 975), (180, 120, 980), (185, 115, 985),
                (190, 110, 990), (195, 105, 995), (200, 100, 1000),
                (205, 95, 1005), (210, 90, 1010), (215, 85, 1015),
                (220, 80, 1020),
                            (100, 200, 900), (105, 195, 905), (110, 190, 910),
                (115, 185, 915), (120, 180, 920), (125, 175, 925),
                (130, 170, 930), (135, 165, 935), (140, 160, 940),
                (145, 155, 945), (150, 150, 950), (155, 145, 955),
                (160, 140, 960), (165, 135, 965), (170, 130, 970),
                (175, 125, 975), (180, 120, 980), (185, 115, 985),
                (190, 110, 990), (195, 105, 995), (200, 100, 1000),
                (205, 95, 1005), (210, 90, 1010), (215, 85, 1015),
                (220, 80, 1020)
            ]
            
            steps = dll.process(sample_acc_data)
            print(f"检测到的步数: {steps}")
            
    except Exception as e:
        print(f"错误: {e}")