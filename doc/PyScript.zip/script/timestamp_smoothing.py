import pandas as pd
import numpy as np

def _smooth_packet_counts_logic(counts_array, tolerance):
    """
    改进版平滑算法：
    1. 从两端向中心逐步推平(避免堵塞点问题)
    2. 严格左优先策略
    3. 异常多发检测与警告
    返回 (smoothed_array, anomalies)
    """
    smoothed = counts_array.copy()
    n = len(smoothed)
    anomalies = []

    pending_indices = [i for i in range(n) if smoothed[i] > 1]
    max_iterations = n * 10
    iteration = 0

    while pending_indices and iteration < max_iterations:
        iteration += 1
        made_progress = False

        for i in list(pending_indices):
            if smoothed[i] <= 1:
                pending_indices.remove(i)
                continue

            moved = False

            # 左侧优先
            for dist in range(1, tolerance + 1):
                left_idx = i - dist
                if left_idx >= 0 and smoothed[left_idx] == 0:
                    smoothed[i] -= 1
                    smoothed[left_idx] += 1
                    moved = True
                    made_progress = True
                    break

            # 右侧
            if not moved:
                for dist in range(1, tolerance + 1):
                    right_idx = i + dist
                    if right_idx < n and smoothed[right_idx] == 0:
                        smoothed[i] -= 1
                        smoothed[right_idx] += 1
                        moved = True
                        made_progress = True
                        break

            if smoothed[i] <= 1:
                pending_indices.remove(i)

        if not made_progress:
            break

    for i in range(n):
        if smoothed[i] > 1:
            excess = smoothed[i] - 1
            anomalies.append({
                'index': i,
                'original_count': counts_array[i],
                'smoothed_count': smoothed[i],
                'excess_packets': excess
            })

    return smoothed, anomalies


def assign_segments(df: pd.DataFrame, time_col='unix_timestamp', tolerance=4) -> pd.DataFrame:
    df = df.copy()
    df = df.sort_index()
    ts_series = df[time_col].astype(float)
    diffs = ts_series.diff()
    segment_threshold = tolerance * 2
    is_break = (diffs > segment_threshold) | (diffs < 0)
    is_break = is_break.fillna(False)
    df['seg_id'] = is_break.cumsum()
    return df


def generate_smoothed_skeleton(segmented_df: pd.DataFrame, time_col='unix_timestamp', tolerance=4) -> pd.DataFrame:
    valid_data = segmented_df.dropna(subset=[time_col])
    if len(valid_data) == 0:
        return pd.DataFrame(columns=['seg_id', 'uniform_unix', 'packet_count', 'smoothed_count'])

    seg_ranges = valid_data.groupby('seg_id')[time_col].agg(['min', 'max'])
    seg_ranges['uniform_unix'] = [
        range(int(row['min']), int(row['max']) + 1)
        for _, row in seg_ranges.iterrows()
    ]

    skeleton_df = seg_ranges.explode('uniform_unix')[['uniform_unix']].reset_index()
    skeleton_df['uniform_unix'] = skeleton_df['uniform_unix'].astype(int)

    raw_counts = valid_data.groupby(['seg_id', time_col]).size().reset_index(name='raw_count')

    final_df = pd.merge(
        skeleton_df,
        raw_counts,
        left_on=['seg_id', 'uniform_unix'],
        right_on=['seg_id', time_col],
        how='left'
    )

    final_df['packet_count'] = final_df['raw_count'].fillna(0).astype(int)

    smoothed_results = []
    all_anomalies = []

    for seg_id in final_df['seg_id'].unique():
        mask = final_df['seg_id'] == seg_id
        segment_counts = final_df.loc[mask, 'packet_count'].values
        smoothed_counts, anomalies = _smooth_packet_counts_logic(segment_counts, tolerance)
        smoothed_results.extend(smoothed_counts)
        if anomalies:
            for anom in anomalies:
                global_idx = final_df[mask].index[anom['index']]
                unix_time = final_df.loc[global_idx, 'uniform_unix']
                all_anomalies.append({
                    'seg_id': seg_id,
                    'unix_timestamp': unix_time,
                    'original_count': anom['original_count'],
                    'smoothed_count': anom['smoothed_count'],
                    'excess_packets': anom['excess_packets']
                })

    final_df['smoothed_count'] = smoothed_results

    if all_anomalies:
        for anom in all_anomalies:
            print(f"[Segment {anom['seg_id']}] Timestamp={anom['unix_timestamp']} | "
                  f"原始包数={anom['original_count']} | 平滑后={anom['smoothed_count']} | "
                  f"无法分散的多余包数={anom['excess_packets']}")

    return final_df[['seg_id', 'uniform_unix', 'packet_count', 'smoothed_count']]


def apply_correction_to_rows(segmented_df: pd.DataFrame, skeleton_df: pd.DataFrame) -> pd.DataFrame:
    result_df = segmented_df.copy()
    result_df['final_corrected_unix'] = result_df['unix_timestamp']

    seg_ids = skeleton_df['seg_id'].unique()

    for seg_id in seg_ids:
        mask_skel = skeleton_df['seg_id'] == seg_id
        segment_skel = skeleton_df[mask_skel]

        mask_orig = result_df['seg_id'] == seg_id
        segment_orig_indices = result_df[mask_orig].index

        expanded_timestamps = np.repeat(
            segment_skel['uniform_unix'].values,
            segment_skel['smoothed_count'].values
        )

        n_orig = len(segment_orig_indices)
        n_new = len(expanded_timestamps)

        if n_orig == n_new:
            result_df.loc[segment_orig_indices, 'final_corrected_unix'] = expanded_timestamps
        else:
            min_len = min(n_orig, n_new)
            print(f"  Warning: Segment {seg_id} length mismatch. Original rows: {n_orig}, Expanded timestamps: {n_new}. Using first {min_len} elements.")
            result_df.loc[segment_orig_indices[:min_len], 'final_corrected_unix'] = expanded_timestamps[:min_len]

    return result_df


def process_timestamp_correction(df: pd.DataFrame, tolerance: int = 4) -> pd.DataFrame:
    df_segmented = assign_segments(df, tolerance=tolerance)
    df_skeleton = generate_smoothed_skeleton(df_segmented, tolerance=tolerance)
    df_final = apply_correction_to_rows(df_segmented, df_skeleton)
    df_final['unix_diff'] = df_final['final_corrected_unix'] - df_final['unix_timestamp']
    return df_final


def detect_jitter_patterns(df, time_col='unix_timestamp'):
    df = df.sort_index()
    group_counts = df.groupby(time_col).size()
    burst_ts = group_counts[group_counts > 1].index

    burst_list = []
    for ts in burst_ts:
        rows = df[df[time_col] == ts].index.tolist()
        burst_list.append({
            'unix_timestamp': ts,
            'count': len(rows),
            'row_indices': rows
        })

    burst_df = pd.DataFrame(burst_list)
    if not burst_df.empty:
        burst_df = burst_df[['unix_timestamp', 'count', 'row_indices']]

    time_diff = df[time_col].diff()
    gap_indices = time_diff[time_diff > 1].index

    gap_list = []
    for idx in gap_indices:
        curr_ts = df.loc[idx, time_col]
        prev_ts = df.loc[idx, time_col] - time_diff.loc[idx]
        missing_len = int(time_diff.loc[idx] - 1)
        start_missing_ts = int(prev_ts + 1)
        gap_list.append({
            'row_pair': (idx - 1, idx),
            'gap_start_unix': start_missing_ts,
            'missing_seconds': missing_len
        })

    gap_df = pd.DataFrame(gap_list)
    return burst_df, gap_df

# __all__ = [
#     'assign_segments', 'generate_smoothed_skeleton', 'apply_correction_to_rows',
#     'process_timestamp_correction', 'detect_jitter_patterns', 'smooth_packet_counts',
#     '_smooth_packet_counts_logic', 'apply_smoothed_timestamps'
# ]


# ===== 测试代码 =====
if __name__ == "__main__":

    # 测试用例1: 中等间隙
    test_medium_gap = pd.DataFrame({
        'unix_timestamp': [10, 10, 11, 17, 18]  # gap=6,堆积在10
    })

    bursts, gaps = detect_jitter_patterns(test_medium_gap, 'unix_timestamp')
    print("--- 1. 多包堆积检测 (Bursts) ---")
    print(bursts.to_string(index=False))
    print("\n--- 2. 时间空缺检测 (Gaps) ---")
    print(gaps .to_string(index=False) if 'gap_df' in locals() else gaps.to_string(index=False))

    print("\n")
    print("测试1: 中等间隙 (gap=6)")
    result1 = process_timestamp_correction(test_medium_gap, tolerance=4)
    print(result1[['unix_timestamp', 'final_corrected_unix', 'seg_id']])

    # 测试用例2: 大间隙
    test_large_gap = pd.DataFrame({
        'unix_timestamp': [10, 11, 21, 22]  # gap=10
    })

    print("\n测试2: 大间隙 (gap=10)")
    result2 = process_timestamp_correction(test_large_gap, tolerance=4)
    print(result2[['unix_timestamp', 'final_corrected_unix', 'seg_id']])