import ctypes
import numpy as np
import gc

# 定义枚举类型
class MotionType:
    NULL = 0
    WALK = 1
    RUN = 2
    CYCLING = 3
    ELLIPTICAL = 4
    ROWING = 5
    SWIMMING = 6
    SKIP_SKIPPING = 7
    OTHER = 8

class MotionDetState:
    NONE = 0
    SUSPECTED = 1
    CONFIRMED = 2
    PAUSE_SUS = 3
    PAUSE_CONFIRMED = 4
    RESUME_SUS = 5
    END_SUS = 6
    END_CONFIRMED = 7

class MotionErrorCode:
    NONE = 0
    NOT_INITIALIZED = 1
    INVALID_PARAM = 2
    NULL_POINTER = 3
    INVALID_TIMESTAMP = 4
    SENSOR_DATA = 5
    LONG_UNWORN = 6

# 定义结构体
class AlgVersion(ctypes.Structure):
    _fields_ = [
        ("major", ctypes.c_uint8),
        ("minor", ctypes.c_uint8),
        ("patch", ctypes.c_uint8)
    ]

class AlgMotionAccAxis(ctypes.Structure):
    _fields_ = [
        ("acc_axis_x", ctypes.POINTER(ctypes.c_int16)),
        ("acc_axis_y", ctypes.POINTER(ctypes.c_int16)),
        ("acc_axis_z", ctypes.POINTER(ctypes.c_int16)),
        ("sensor_size", ctypes.c_uint8),
        ("acc_bits", ctypes.c_uint8),
        ("acc_range", ctypes.c_uint8)
    ]

class MotionActivityData(ctypes.Structure):
    _fields_ = [
        ("unix_timestamp", ctypes.c_uint32),
        ("wear_flag", ctypes.c_uint8),
        ("heartrate", ctypes.c_uint8),
        ("steps", ctypes.c_uint8),
        ("step_freq", ctypes.c_uint16),
        ("activity_level", ctypes.c_uint8),
        ("sport_type", ctypes.c_uint8),
        ("sport_pause_state", ctypes.c_uint8)
    ]

class MotionRecognitionResult(ctypes.Structure):
    _fields_ = [
        ("error_code", ctypes.c_uint32),
        ("init_timer", ctypes.c_uint32),
        ("motion_type", ctypes.c_uint32),
        ("detection_state", ctypes.c_uint32),
        ("activity_motion_time", ctypes.c_uint32),
        ("auto_detect_state", ctypes.c_uint8),
        ("instant_type", ctypes.c_uint8),
        ("hr_rising", ctypes.c_uint8),
        ("hr_avg", ctypes.c_uint8),
        ("steps_per_minute", ctypes.c_uint16),
        ("acc_feature", ctypes.c_uint16),
        ("avg_activity_level", ctypes.c_uint32),
        ("wear_flag", ctypes.c_uint8),
        ("unworn_seconds", ctypes.c_uint16)
    ]

class MotionRecognitionInitConfig(ctypes.Structure):
    _fields_ = [
        ("is_manual_detect", ctypes.c_bool),
        ("manual_motion_type", ctypes.c_uint32),
        ("suspect_sec", ctypes.c_uint16),
        ("confirm_sec", ctypes.c_uint16),
        ("run_suspect_sec", ctypes.c_uint16),
        ("run_confirm_sec", ctypes.c_uint16),
        ("pause_check_sec", ctypes.c_uint16),
        ("resume_confirm_sec", ctypes.c_uint16),
        ("end_suspect_sec", ctypes.c_uint16),
        ("end_confirm_sec", ctypes.c_uint16)
    ]

def my_print_callback(message):
    print(f"{message}", end='')

class MotionRecognitionDLL:
    def __init__(self, dll_path, print_callback=my_print_callback):
        self.dll_path = dll_path
        self.dll = ctypes.CDLL(dll_path)
        self.dll_handle = None  # 保存DLL句柄用于释放
        
        # 设置函数签名
        self.dll.alg_motion_recognition_init.argtypes = [ctypes.POINTER(MotionRecognitionInitConfig)]
        self.dll.alg_motion_recognition_init_default.argtypes = []
        self.dll.alg_motion_recognition_process.argtypes = [AlgMotionAccAxis, MotionActivityData]
        self.dll.alg_motion_recognition_process.restype = ctypes.POINTER(MotionRecognitionResult)
        self.dll.get_motion_recognition_alg_version.restype = AlgVersion
        
        # 设置回调函数签名
        self.dll.alg_set_print_cb.argtypes = [ctypes.CFUNCTYPE(None, ctypes.c_char_p)]
        
        # 获取DLL句柄(用于释放)
        try:
            self.dll_handle = self.dll._handle
        except AttributeError:
            # 在某些Python版本中可能没有_handle属性
            self.dll_handle = None
        
        # 初始化标志
        self.initialized = False
        self._dll_released = False  # 标记是否已释放
        
        # 回调函数引用(防止垃圾回收)
        self._print_callback = None

        self.set_print_callback(print_callback)
    
    def __enter__(self):
        """上下文管理器入口"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.close()
        return False
    
    def set_print_callback(self, callback_func):
        """
        设置打印回调函数
        
        Args:
            callback_func: Python函数,接受一个字符串参数(const char*)
        """
        if callback_func is None:
            # 清除回调
            self.dll.alg_set_print_cb(None)
            self._print_callback = None
        else:
            # 定义回调函数类型
            PRINT_CALLBACK_TYPE = ctypes.CFUNCTYPE(None, ctypes.c_char_p)
            
            # 创建回调包装器
            def callback_wrapper(c_str):
                try:
                    # 将C字符串转换为Python字符串
                    py_str = c_str.decode('utf-8') if c_str else ""
                    callback_func(py_str)
                except Exception as e:
                    print(f"Error in print callback: {e}")
            
            # 创建ctypes回调
            c_callback = PRINT_CALLBACK_TYPE(callback_wrapper)
            
            # 设置回调
            self.dll.alg_set_print_cb(c_callback)
            
            # 保存引用防止垃圾回收
            self._print_callback = c_callback
    
    def init_default(self):
        """使用默认配置初始化"""
        self.dll.alg_motion_recognition_init_default()
        self.initialized = True
        # print("The motion recognition algorithm has been initialized using the default configuration.")
    
    def init_with_config(self, config):
        """使用自定义配置初始化"""
        self.dll.alg_motion_recognition_init(ctypes.byref(config))
        self.initialized = True
        print("The motion recognition algorithm has been initialized using a custom configuration.")
    
    def process(self, acc_data, activity_data):
        """处理一秒的数据"""
        if not self.initialized:
            raise RuntimeError("init_default() or init_with_config()")
        
        # 转换加速度数据
        acc_axis = self._prepare_acc_data(acc_data)
        
        # 调用处理函数
        result_ptr = self.dll.alg_motion_recognition_process(acc_axis, activity_data)
        
        # 复制结果(因为返回的是指针,可能有生命周期问题)
        result = result_ptr.contents
        
        return result
    
    def _prepare_acc_data(self, acc_data):
        """准备加速度数据结构体"""
        # 处理 NumPy 数组
        if isinstance(acc_data, np.ndarray):
            if acc_data.ndim == 2:
                if acc_data.shape[1] == 3:
                    # 格式: (n, 3) - 每行是 [x, y, z]
                    x_data = acc_data[:, 0].astype(int).tolist()
                    y_data = acc_data[:, 1].astype(int).tolist()
                    z_data = acc_data[:, 2].astype(int).tolist()
                elif acc_data.shape[0] == 3:
                    # 格式: (3, n) - 每行分别是 x、y、z 序列
                    x_data = acc_data[0, :].astype(int).tolist()
                    y_data = acc_data[1, :].astype(int).tolist()
                    z_data = acc_data[2, :].astype(int).tolist()
                else:
                    raise ValueError("NumPy array shape must be (n, 3) or (3, n)")
            else:
                raise ValueError("NumPy array must be 2-dimensional")
        # 处理列表/元组格式
        elif isinstance(acc_data, (list, tuple)):
            if len(acc_data) == 0:
                raise ValueError("acc_data Cannot be empty")
            
            # 检查格式：可能是 [(x,y,z), ...] 或 [[x,y,z], ...]
            first_elem = acc_data[0]
            if isinstance(first_elem, (list, tuple)) and len(first_elem) == 3:
                # 格式: [(x,y,z), ...] 或 [[x,y,z], ...]
                x_data = [int(point[0]) for point in acc_data]
                y_data = [int(point[1]) for point in acc_data]
                z_data = [int(point[2]) for point in acc_data]
            else:
                raise ValueError("The acc_data format is incorrect. Each element is expected to be a tuple or list containing [x, y, z].")
        else:
            raise ValueError("acc_data must be a list, tuple, or NumPy array")
        
        # 转换为ctypes数组
        x_ctypes = (ctypes.c_int16 * len(x_data))(*x_data)
        y_ctypes = (ctypes.c_int16 * len(y_data))(*y_data)
        z_ctypes = (ctypes.c_int16 * len(z_data))(*z_data)
        
        acc_axis = AlgMotionAccAxis()
        acc_axis.acc_axis_x = x_ctypes
        acc_axis.acc_axis_y = y_ctypes
        acc_axis.acc_axis_z = z_ctypes
        acc_axis.sensor_size = len(x_data)
        acc_axis.acc_bits = 16  # 假设16位
        acc_axis.acc_range = 2  # 假设±2g
        
        return acc_axis
    
    def get_version(self):
        """获取算法版本"""
        return self.dll.get_motion_recognition_alg_version()
    
    def close(self):
        """清理资源 - 手动释放DLL"""
        if not hasattr(self, '_dll_released') or not self._dll_released:
            try:
                # 在Windows上手动释放DLL
                if hasattr(self, 'dll_handle') and self.dll_handle is not None:
                    # 加载kernel32.dll来释放库
                    kernel32 = ctypes.windll.kernel32
                    kernel32.FreeLibrary.argtypes = [ctypes.c_void_p]
                    kernel32.FreeLibrary(self.dll_handle)
                    # print("DLL已手动释放")
                else:
                    print("DLL handle is unavailable; use garbage collection to release it.")
                
                # 删除DLL对象的引用
                if hasattr(self, 'dll'):
                    del self.dll
                
                # 强制垃圾回收
                gc.collect()
                
                self._dll_released = True
                # print("MotionRecognitionDLL资源已清理")
                
            except Exception as e:
                print(f"Error releasing DLL: {e}")
                # 即使出错也标记为已释放,避免重复释放
                self._dll_released = True
    
    def __del__(self):
        """析构函数 - 确保资源被释放"""
        self.close()

    def result_to_dict(self,result):
        return {
            'error_code': result.error_code,
            'init_timer': result.init_timer,
            'motion_type': result.motion_type,
            'detection_state': result.detection_state,
            'activity_motion_time': result.activity_motion_time,
            'auto_detect_state': result.auto_detect_state,
            'instant_type': result.instant_type,
            'hr_rising': result.hr_rising,
            'hr_avg': result.hr_avg,
            'steps_per_minute': result.steps_per_minute,
            'acc_feature': result.acc_feature,
            'avg_activity_level': result.avg_activity_level,
            'wear_flag': result.wear_flag,
            'unworn_seconds': result.unworn_seconds
        }



if __name__ == "__main__":
    dll_path = r"G:\ncs_workspace\application\algorithm_lib\alg_motion_recognition\build\bin\alg_motion_recognition_ring.dll"
    try:
        # 使用上下文管理器自动管理DLL资源
        with MotionRecognitionDLL(dll_path) as dll:
            
            
            version = dll.get_version()
            print(f"alg_motion_recognition_ring Ver: {version.major}.{version.minor}.{version.patch}")

            dll.init_default()

    finally:
        pass