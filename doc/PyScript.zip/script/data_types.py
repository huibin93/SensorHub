"""
数据类型映射和常量定义
Data type mappings and constants
"""

# 数据类型映射(16进制 -> 英文名称)
DATA_TYPE_MAPPING = {
    "00": "BASE_INFO",
    "14": "RAW_PPG_DAC",
    "15": "RAW_PPG_GREEN", 
    "16": "RAW_PPG_RED",
    "17": "RAW_PPG_IR",
    "18": "RAW_ACC",
    "19": "RAW_GYRO",
    "1A": "RAW_GEOM",
    "1B": "RAW_PPG_SAR",
    "1C": "RAW_ECG",
    "1D": "RAW_EDA",
    "1E": "RAW_BIA",
    "1F": "RAW_UV",
    "20": "RAW_BLUE",
    "21": "RAW_ACC_TO_PPG",
    "26": "RAW_PPG_RED_IR",
    "32": "RAW_GPS",
    "33": "AMBIENT_INFO",
    "67": "SLEEP_INFO",
    "68": "HRV_INFO",
    "69": "MOTION_INFO",
    "70": "SWIMMING_INFO",
    "71": "WEAR_INFO",
    "72": "HEART_GSEN_X_INFO",
    "73": "HEART_GSEN_Y_INFO",
    "74": "HEART_GSEN_Z_INFO",
    "75": "VO2MAX_INFO",
    "76": "HEART_PPG_1_INFO",
    "77": "HEART_PPG_2_INFO",
    "78": "HEART_ACC_INFO",
    "7A": "HEART_ACC_X_INFO",
    "7B": "HEART_ACC_Y_INFO",
    "7C": "HEART_ACC_Z_INFO",
    "80": "PAH_DATA",
    "81": "TYHX_DATA",
    "82": "TYHX_AGC_DATA",
    "90": "GNSS_NAVIGATION_DATA",
    "91": "GREEN_PSP_INFO",
    "92": "RED_PSP_INFO",
    "93": "IR_PSP_INFO",
    "94": "SLEEP_PSP_INFO",
    "95": "ADI_AGC_INFO",
    "96": "TIME_PSP_INFO",
    "97": "HRV_PSP_INFO",
    "98": "TRAINING_LOAD_INFO",
    "99": "CREEK_HR_INFO"
}

# 中文数据类型映射
DATA_TYPE_CHINESE = {
    "00": "基础信息",
    "14": "原始PPG DAC",
    "15": "原始PPG绿光", 
    "16": "原始PPG红光",
    "17": "原始PPG红外",
    "18": "原始加速度",
    "19": "原始陀螺仪",
    "1A": "原始地磁",
    "1B": "原始PPG SAR",
    "1C": "原始心电",
    "1D": "原始皮肤电导",
    "1E": "原始生物阻抗",
    "1F": "原始紫外光感",
    "20": "原始蓝光感",
    "21": "原始加速度到PPG",
    "26": "原始PPG红灯红外",
    "32": "原始GPS",
    "33": "环境信息",
    "67": "睡眠信息",
    "68": "心率变异性信息",
    "69": "运动识别",
    "70": "游泳信息",
    "71": "佩戴信息",
    "72": "心率重力感应X轴",
    "73": "心率重力感应Y轴",
    "74": "心率重力感应Z轴",
    "75": "最大摄氧量信息",
    "76": "心率PPG1信息",
    "77": "心率PPG2信息",
    "78": "心率加速度信息",
    "7A": "心率加速度X轴",
    "7B": "心率加速度Y轴",
    "7C": "心率加速度Z轴",
    "80": "PAH数据",
    "81": "TYHX数据",
    "82": "TYHX AGC数据",
    "90": "GNSS导航数据",
    "91": "绿光PSP信息",
    "92": "红光PSP信息",
    "93": "红外PSP信息",
    "94": "睡眠PSP信息",
    "95": "ADI AGC信息",
    "96": "时间PSP信息",
    "97": "心率变异性PSP信息",
    "98": "训练负荷信息",
    "99": "CREEK心率信息"
}


def get_readable_data_type(hex_type: str) -> str:
    """
    将16进制数据类型转换为可读名称
    
    Parameters:
    -----------
    hex_type : str
        16进制数据类型,如 "00", "15", "71" 等
    
    Returns:
    --------
    str
        可读的英文名称,如 "BASE_INFO", "RAW_PPG_GREEN" 等
        如果类型未知,返回 "UNKNOWN(hex_type)"
    """
    return DATA_TYPE_MAPPING.get(hex_type.upper(), f"UNKNOWN({hex_type})")


def get_chinese_data_type(hex_type: str) -> str:
    """
    将16进制数据类型转换为中文名称
    
    Parameters:
    -----------
    hex_type : str
        16进制数据类型,如 "00", "15", "71" 等
    
    Returns:
    --------
    str
        中文名称,如 "基础信息", "原始PPG绿光" 等
        如果类型未知,返回 "未知类型(hex_type)"
    """
    return DATA_TYPE_CHINESE.get(hex_type.upper(), f"未知类型({hex_type})")


def get_full_data_type(hex_type: str) -> str:
    """
    获取完整的数据类型信息：英文和中文
    
    Parameters:
    -----------
    hex_type : str
        16进制数据类型,如 "00", "15", "71" 等
    
    Returns:
    --------
    str
        格式化的字符串,包含英文和中文名称
        例如: "BASE_INFO            基础信息              "
    """
    english = get_readable_data_type(hex_type)
    chinese = get_chinese_data_type(hex_type)
    return f"{english:<20}  {chinese:<20} "
