import datetime
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as patches

# Optional clipboard support
try:
    import pyperclip
    HAS_CLIPBOARD = True
except Exception:
    HAS_CLIPBOARD = False


class InteractiveChart:
    """Interactive acc/step chart with hover annotations and click-to-copy."""
    def __init__(self, expanded_acc_df, base_info_df, file_name):
        self.file_name = file_name
        self.process_data(expanded_acc_df, base_info_df)
        self.init_plot()
        self.init_interactive()

    def process_data(self, acc_df, step_df):
        if acc_df is not None and not acc_df.empty:
            df = acc_df.sort_values('unix_timestamp').reset_index(drop=True)
            self.acc_times = df['unix_timestamp'].values
            self.acc_data = {
                'x': df['x'].values,
                'y': df['y'].values,
                'z': df['z'].values
            }
            self.start_time = self.acc_times[0]
        else:
            self.acc_times = np.array([])
            self.start_time = 0

        if step_df is not None and not step_df.empty and 'step' in step_df.columns:
            df = step_df.sort_values('unix_timestamp').reset_index(drop=True)
            self.step_times = df['unix_timestamp'].values
            self.step_cum = df['step'].values
            self.step_diff = np.diff(self.step_cum, prepend=self.step_cum[0])
            if self.start_time == 0 and len(self.step_times) > 0:
                self.start_time = self.step_times[0]
        else:
            self.step_times = np.array([])
            self.step_cum = np.array([])
            self.step_diff = np.array([])

    def init_plot(self):
        self.fig, (self.ax1, self.ax2) = plt.subplots(2, 1, figsize=(20, 12), sharex=True)
        self.fig.suptitle(self.file_name, fontsize=12)

        if len(self.acc_times) > 0:
            self.ax1.plot(self.acc_times, self.acc_data['x'], label='X', c='r', lw=0.5)
            self.ax1.plot(self.acc_times, self.acc_data['y'], label='Y', c='g', lw=0.5)
            self.ax1.plot(self.acc_times, self.acc_data['z'], label='Z', c='b', lw=0.5)
            self.ax1.legend(loc='upper right', fontsize='small')
            self.ax1.set_ylabel('Acceleration')
            self.ax1.grid(True, alpha=0.3)

        self.ax2_twin = self.ax2.twinx()
        if len(self.step_times) > 0:
            self.ax2.plot(self.step_times, self.step_diff, '.-', c='purple', lw=0.5, markersize=2, label='Diff')
            self.ax2_twin.plot(self.step_times, self.step_cum, c='orange', lw=1, alpha=0.6, label='Total')
            self.ax2.set_ylabel('Step Diff')
            self.ax2_twin.set_ylabel('Cumulative Steps')
            h1, l1 = self.ax2.get_legend_handles_labels()
            h2, l2 = self.ax2_twin.get_legend_handles_labels()
            self.ax2.legend(h1+h2, l1+l2, loc='upper left', fontsize='small')
            self.ax2.grid(True, alpha=0.3)

        self.ax2.ticklabel_format(axis='x', style='plain', useOffset=True)
        plt.tight_layout()

    def init_interactive(self):
        self.vl1 = self.ax1.axvline(x=self.start_time, c='k', ls='--', alpha=0.6, visible=False, zorder=999)
        self.vl2 = self.ax2.axvline(x=self.start_time, c='k', ls='--', alpha=0.6, visible=False, zorder=999)

        self.default_bbox = dict(boxstyle="round", fc="w", alpha=0.9)
        self.annot1 = self.ax1.annotate("", xy=(0,0), xytext=(10,10), textcoords="offset points",
                                        bbox=self.default_bbox, visible=False, zorder=999)
        self.annot2 = self.ax2.annotate("", xy=(0,0), xytext=(10,10), textcoords="offset points",
                                        bbox=self.default_bbox, visible=False, zorder=999)

        self.fig.canvas.mpl_connect('motion_notify_event', self.on_move)
        self.fig.canvas.mpl_connect('button_press_event', self.on_click)

    def update_annot(self, ax_idx, x, y, text):
        annot = self.annot1 if ax_idx == 1 else self.annot2
        ax = self.ax1 if ax_idx == 1 else self.ax2
        annot.xy = (x, y)
        annot.set_text(text)
        annot.set_visible(True)
        xlim = ax.get_xlim()
        if x > (xlim[0] + xlim[1]) / 2:
            annot.set_position((-10, 10)); annot.set_ha('right')
        else:
            annot.set_position((10, 10)); annot.set_ha('left')

    def on_move(self, event):
        if not event.inaxes:
            self.vl1.set_visible(False); self.vl2.set_visible(False)
            self.annot1.set_visible(False); self.annot2.set_visible(False)
            self.fig.canvas.draw_idle()
            return

        x_mouse = event.xdata

        if event.inaxes == self.ax1 and len(self.acc_times) > 0:
            idx = np.searchsorted(self.acc_times, x_mouse)
            idx = np.clip(idx, 0, len(self.acc_times)-1)
            if idx > 0 and abs(self.acc_times[idx-1] - x_mouse) < abs(self.acc_times[idx] - x_mouse):
                idx -= 1
            curr_x = self.acc_times[idx]
            self.vl1.set_xdata([curr_x, curr_x])
            self.vl2.set_xdata([curr_x, curr_x])
            self.vl1.set_visible(True); self.vl2.set_visible(True)
            txt = (f"T: {int(curr_x)}\n"
                   f"X: {self.acc_data['x'][idx]:.2f}\n"
                   f"Y: {self.acc_data['y'][idx]:.2f}\n"
                   f"Z: {self.acc_data['z'][idx]:.2f}")
            self.update_annot(1, curr_x, self.acc_data['x'][idx], txt)
            self.annot2.set_visible(False)

        elif (event.inaxes == self.ax2 or event.inaxes == self.ax2_twin) and len(self.step_times) > 0:
            idx = np.searchsorted(self.step_times, x_mouse)
            idx = np.clip(idx, 0, len(self.step_times)-1)
            if idx > 0 and abs(self.step_times[idx-1] - x_mouse) < abs(self.step_times[idx] - x_mouse):
                idx -= 1
            curr_x = self.step_times[idx]
            self.vl1.set_xdata([curr_x, curr_x])
            self.vl2.set_xdata([curr_x, curr_x])
            self.vl1.set_visible(True); self.vl2.set_visible(True)
            txt = (f"T: {int(curr_x)}\n"
                   f"Diff: {self.step_diff[idx]}\n"
                   f"Total: {self.step_cum[idx]}")
            self.update_annot(2, curr_x, self.step_diff[idx], txt)
            self.annot1.set_visible(False)

        self.fig.canvas.draw_idle()

    def on_click(self, event):
        if event.button != 1 or not event.inaxes:
            return

        target_annot = None
        if self.annot1.get_visible() and event.inaxes == self.ax1:
            target_annot = self.annot1
        elif self.annot2.get_visible() and (event.inaxes == self.ax2 or event.inaxes == self.ax2_twin):
            target_annot = self.annot2

        if target_annot:
            text_content = target_annot.get_text()
            if HAS_CLIPBOARD:
                try:
                    pyperclip.copy(text_content)
                    print(f"✅ 已复制到剪切板:\n{text_content}\n" + "-"*30)
                except Exception as e:
                    print(f"❌ 复制失败: {e}")
            else:
                print(f"📋 (模拟复制) 内容如下:\n{text_content}\n" + "-"*30)
            target_annot.get_bbox_patch().set_facecolor('#fffacd')
            self.fig.canvas.draw_idle()
            def restore_color():
                target_annot.get_bbox_patch().set_facecolor('w')
                self.fig.canvas.draw_idle()
            timer = self.fig.canvas.new_timer(interval=200)
            timer.add_callback(restore_color)
            timer.start()


class RegionAnnotator:
    def __init__(self, ax, data_x=None, color='red', alpha=0.2):
        self.ax = ax
        self.data_x = data_x
        self.color = color
        self.alpha = alpha
        self.is_selecting = False
        self.start_x = None
        self.rect = None
        self.start_line = None
        self.regions = []
        self.cid_click = self.ax.figure.canvas.mpl_connect('button_press_event', self.on_click)
        self.cid_move = self.ax.figure.canvas.mpl_connect('motion_notify_event', self.on_move)
        print("✅ 标注工具已激活: \n  1. 左键点击设置 [起点]\n  2. 移动鼠标预览\n  3. 左键点击设置 [终点] 并输入标签\n  4. 右键点击取消当前选择")

    def on_click(self, event):
        if event.inaxes != self.ax:
            return
        if event.button == 3:
            self.reset_selection()
            print("🚫 操作已取消")
            self.ax.figure.canvas.draw_idle()
            return
        if event.button == 1:
            if not self.is_selecting:
                self.is_selecting = True
                self.start_x = event.xdata
                self.start_line = self.ax.axvline(self.start_x, color=self.color, linestyle='--', alpha=0.8)
                ylim = self.ax.get_ylim()
                self.rect = patches.Rectangle((self.start_x, ylim[0]), 0, ylim[1]-ylim[0], linewidth=0, edgecolor='none', facecolor=self.color, alpha=self.alpha)
                self.ax.add_patch(self.rect)
                print(f"📍 起点设定: {int(self.start_x)}")
                self.ax.figure.canvas.draw_idle()
            else:
                end_x = event.xdata
                x1, x2 = sorted([self.start_x, end_x])
                label_text = input(f"请输入区域标签 (范围 {int(x1)} - {int(x2)}): ")
                if not label_text:
                    label_text = "Region"
                final_rect = self.ax.axvspan(x1, x2, color=self.color, alpha=self.alpha)
                center_x = (x1 + x2) / 2
                ylim = self.ax.get_ylim()
                text_y = ylim[1] - (ylim[1] - ylim[0]) * 0.05
                text_obj = self.ax.text(center_x, text_y, label_text, ha='center', va='top', fontsize=9, fontweight='bold', bbox=dict(facecolor='white', alpha=0.7, edgecolor='none', boxstyle='round,pad=0.2'))
                self.regions.append({
                    'start': x1,
                    'end': x2,
                    'label': label_text,
                    'rect': final_rect,
                    'text': text_obj
                })
                print(f"💾 已保存选区: [{label_text}] {int(x1)} -> {int(x2)}")
                self.reset_selection()
                self.ax.figure.canvas.draw_idle()

    def on_move(self, event):
        if not self.is_selecting or event.inaxes != self.ax:
            return
        current_x = event.xdata
        width = current_x - self.start_x
        if self.rect is not None:
            self.rect.set_width(width)
        self.ax.figure.canvas.draw_idle()

    def reset_selection(self):
        self.is_selecting = False
        self.start_x = None
        if self.rect:
            try:
                self.rect.remove()
            except Exception:
                pass
            self.rect = None
        if self.start_line:
            try:
                self.start_line.remove()
            except Exception:
                pass
            self.start_line = None

    def get_labeled_regions(self):
        data = []
        for r in self.regions:
            data.append({
                'Label': r['label'],
                'Start_Time': r['start'],
                'End_Time': r['end'],
                'Duration': r['end'] - r['start']
            })
        return pd.DataFrame(data)


if __name__ == '__main__':
    # Quick demo for manual run
    start_ts = int(datetime.datetime.now().timestamp())
    x_data = np.linspace(start_ts, start_ts + 100, 500)
    y_data = np.sin((x_data - start_ts) * 0.5) + np.random.normal(0, 0.1, 500)
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(x_data, y_data, label='Signal')
    ax.set_title("Click LEFT to Start/Stop selection, RIGHT to Cancel")
    ax.ticklabel_format(axis='x', style='plain', useOffset=True)
    ax.legend()
    annotator = RegionAnnotator(ax, x_data, color='green', alpha=0.3)
    plt.show()
