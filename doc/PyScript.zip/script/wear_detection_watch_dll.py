import ctypes
import numpy as np
import gc
import pandas as pd
import faulthandler

faulthandler.enable()

# 定义枚举类型
class WearReturnType:
    DETECTING = 0
    RING_IR_MODE = 11
    RING_HR_MODE = 12
    RING_SPORT_HR_MODE = 13
    RING_SPO2_MODE = 14
    RING_OTHER_MODE = 15
    RING_ERROR_MODE = 16
    SPO2_MODE = 20
    PPG_REQUEST = 250
    PPG_STOP = 251

class WearErrorNo:
    NONE = 0
    CHANNEL_NUM = 1
    SAMPLING_FREQ = 2
    ACC_STATIC = 3
    DELAY_UNWEAR = 4
    SNR_LOW = 5
    SPO2_HR_ABNORMAL = 6
    GREEN_UNWEAR_COUNT = 7
    DATA_ERROR = 8
    AMBIENT_LIGHT = 9

class WearFlag:
    NOT_WEARING = 0
    WEARING = 1
    DETECTING = 9
    NULL = 255

class WearMeasureType:
    NONE = 0
    WEAR_IR = 1
    SPO2 = 2
    HRS = 3
    SPORT_HRS = 4
    PRESSURE = 5
    HRV = 6
    BREATHING_RATE = 7
    GREEN_PPG = 255

# 定义结构体
class AlgVersion(ctypes.Structure):
    _fields_ = [
        ("major", ctypes.c_uint8),
        ("minor", ctypes.c_uint8),
        ("patch", ctypes.c_uint8)
    ]

class WearingAccAxis(ctypes.Structure):
    _fields_ = [
        ("acc_axis_x", ctypes.POINTER(ctypes.c_int16)),
        ("acc_axis_y", ctypes.POINTER(ctypes.c_int16)),
        ("acc_axis_z", ctypes.POINTER(ctypes.c_int16)),
        ("sensor_size", ctypes.c_uint8),
        ("acc_bits", ctypes.c_uint8),
        ("acc_range", ctypes.c_uint8),
        ("sensor_type", ctypes.c_uint8)
    ]

# 注意：根据 alg_wear_watch.h 修改了结构体
class WearingPpgSensors(ctypes.Structure):
    _fields_ = [
        ("ppg_g", ctypes.POINTER(ctypes.c_int32)),
        ("ppg_r", ctypes.POINTER(ctypes.c_int32)),
        ("ppg_ir", ctypes.POINTER(ctypes.c_int32)),
        ("ppg_low_ir", ctypes.POINTER(ctypes.c_int32)),
        ("ppg_g_sensor_size", ctypes.c_uint16),
        ("ppg_ir_sensor_size", ctypes.c_uint16),
        ("ppg_r_sensor_size", ctypes.c_uint16),
        ("ppg_low_ir_sensor_size", ctypes.c_uint16),
        ("ppg_g_fs", ctypes.c_uint16),
        ("channel_num", ctypes.c_uint16)
    ]

class WearingAmbientLightSensors(ctypes.Structure):
    _fields_ = [
        ("ambient_light", ctypes.POINTER(ctypes.c_int32)),
        ("ambient_light_sensor_size", ctypes.c_uint16),
        ("ambient_light_channel_num", ctypes.c_uint16)
    ]

class SarSensors(ctypes.Structure):
    _fields_ = [
        ("sar", ctypes.POINTER(ctypes.c_int32)),
        ("sar_nv", ctypes.c_int16),
        ("sar_size", ctypes.c_int8),
        ("sar_adjust", ctypes.c_uint8)
    ]

class WearingData(ctypes.Structure):
    _fields_ = [
        ("measure_type", ctypes.c_uint8),
        ("spo2_alg_ir_result", ctypes.c_uint8),
        ("G_LED", ctypes.c_uint8),
        ("ppg_g_reg_led_value", ctypes.c_uint8),
        ("ppg_g_reg_switch", ctypes.c_uint8),
        ("freq_snr", ctypes.c_uint8),
        ("sport_type", ctypes.c_uint8)
    ]

# 注意：根据 alg_wear_watch.h 修改了结构体
class WearingResult(ctypes.Structure):
    _fields_ = [
        ("wear_flag", ctypes.c_uint8),
        ("error_no", ctypes.c_uint8),
        ("return_type", ctypes.c_uint8),
        ("wear_ir_result", ctypes.c_uint8),
        ("wear_green_result", ctypes.c_uint8),
        ("wear_ambient_result", ctypes.c_uint8),
        ("confusion", ctypes.c_uint8),
        ("peak_cnt", ctypes.c_uint16),
        ("wear_rr_hr", ctypes.c_uint8),
        ("ppg_dc_value", ctypes.c_int32),
        ("green_temp_flag_encode", ctypes.c_uint16),
        ("wear_acc_momentum", ctypes.c_uint16),
        ("amb_std", ctypes.c_int32),
        ("init_timer", ctypes.c_uint32),
        ("state", ctypes.c_uint8)
    ]

# 注意：根据 alg_wear_watch.h 修改了结构体
class AlgWearInitParament(ctypes.Structure):
    _fields_ = [
        ("ppg_low_ir_threshold", ctypes.c_int32),
        ("wear_amb_std_threshold", ctypes.c_int32),
        ("acc_quite_time", ctypes.c_uint16),
        ("ppg_unwear_cnt", ctypes.c_uint8),
        ("green_confusion_threshold", ctypes.c_uint8),
        ("confirmed_recheck_timer", ctypes.c_uint16),
        ("is_ring_flag", ctypes.c_bool)
    ]

def my_print_callback(message):
    print(f"{message}", end='')
    pass

class WearDetectionWatchDLL:
    def __init__(self, dll_path, print_callback=my_print_callback):
        self.dll_path = dll_path
        # 加载DLL
        # 注意: Windows下通常使用 ctypes.CDLL 或 ctypes.WinDLL,这里沿用 CDLL
        self.dll = ctypes.CDLL(dll_path)
        self.dll_handle = None
        
        # 设置函数签名
        self.dll.alg_wear_init.argtypes = [AlgWearInitParament]
        self.dll.alg_wear_init.restype = None
        
        self.dll.alg_wearing_process.argtypes = [
            WearingAccAxis,
            WearingPpgSensors,
            SarSensors,
            WearingData,
            WearingAmbientLightSensors
        ]
        self.dll.alg_wearing_process.restype = WearingResult
        
        self.dll.get_wear_new_alg_version.restype = AlgVersion
        
        # 获取DLL句柄(用于释放)
        try:
            self.dll_handle = self.dll._handle
        except AttributeError:
            self.dll_handle = None
        
        # 初始化标志
        self.initialized = False
        self._dll_released = False

        self.set_print_callback(print_callback)

    def set_print_callback(self, callback_func):
        if callback_func is None:
            # 清除回调
            try:
                self.dll.alg_set_print_cb(None)
            except AttributeError:
                pass
            self._print_callback = None
        else:
            # 定义回调函数类型
            PRINT_CALLBACK_TYPE = ctypes.CFUNCTYPE(None, ctypes.c_char_p)
            
            # 创建回调包装器
            def callback_wrapper(c_str):
                try:
                    # 将C字符串转换为Python字符串
                    py_str = c_str.decode('utf-8') if c_str else ""
                    callback_func(py_str)
                except Exception as e:
                    print(f"Error in print callback: {e}")
            
            # 创建ctypes回调
            c_callback = PRINT_CALLBACK_TYPE(callback_wrapper)
            
            try:
                # 设置回调
                self.dll.alg_set_print_cb(c_callback)
            except AttributeError:
                print("Warning: alg_set_print_cb not found in DLL")
            
            # 保存引用防止垃圾回收
            self._print_callback = c_callback

    def __enter__(self):
        """上下文管理器入口"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.close()
        return False
    
    def init_with_config(self, config):
        """使用自定义配置初始化"""
        if not isinstance(config, AlgWearInitParament):
            raise TypeError("config must be an instance of AlgWearInitParament")
        self.dll.alg_wear_init(config)
        self.initialized = True
    
    def init_default(self, is_ring=False):
        """使用默认配置初始化 (默认为手表模式)"""
        config = AlgWearInitParament()
        # 根据 alg_wear_watch.h 注释,建议 8316 3690 3918 用 5000
        config.ppg_low_ir_threshold = 30000 
        config.wear_amb_std_threshold = 0
        config.acc_quite_time = 0 # 
        config.ppg_unwear_cnt = 1 # 默认5
        config.green_confusion_threshold = 0
        config.confirmed_recheck_timer = 300
        config.is_ring_flag = 0 # 0否,1是
        
        self.dll.alg_wear_init(config)
        self.initialized = True
    
    def process(self, acc_axis=None, ppg_sensors=None, sar_sensors=None, wearing_data=None, ambient_light_sensors=None):
        """
        处理佩戴检测数据
        """
        if not self.initialized:
            raise RuntimeError("Please call init_default() or init_with_config() first")

        # 使用默认值初始化未提供的参数
        acc_axis = acc_axis if acc_axis else WearingAccAxis()
        ppg_sensors = ppg_sensors if ppg_sensors else WearingPpgSensors()
        wearing_data = wearing_data if wearing_data else WearingData()
        sar_sensors = sar_sensors if sar_sensors else SarSensors()
        ambient_light_sensors = ambient_light_sensors if ambient_light_sensors else WearingAmbientLightSensors()

        # 调用处理函数
        result = self.dll.alg_wearing_process(
            acc_axis,
            ppg_sensors,
            sar_sensors,
            wearing_data,
            ambient_light_sensors
        )

        return result
    
    def prepare_acc_data(self, acc_data):
        """准备加速度数据结构体"""
        if isinstance(acc_data, np.ndarray):
            if acc_data.ndim != 2 or acc_data.shape[1] != 3:
                raise ValueError("np.ndarray acc_data must have shape (N, 3)")
            acc_data = acc_data.tolist()

        if not isinstance(acc_data, list):
            raise ValueError("acc_data must be a list or np.ndarray")

        if len(acc_data) == 0:
            raise ValueError("acc_data cannot be empty")

        # 检查格式：[(x,y,z), ...] 或 [[x,y,z], ...]
        first_elem = acc_data[0]
        if isinstance(first_elem, (list, tuple)) and len(first_elem) == 3:
            x_data = [int(point[0]) for point in acc_data]
            y_data = [int(point[1]) for point in acc_data]
            z_data = [int(point[2]) for point in acc_data]
        else:
            raise ValueError("acc_data format error. Expected [(x,y,z), ...]")

        # 转换为ctypes数组
        x_ctypes = (ctypes.c_int16 * len(x_data))(*x_data)
        y_ctypes = (ctypes.c_int16 * len(y_data))(*y_data)
        z_ctypes = (ctypes.c_int16 * len(z_data))(*z_data)

        acc_axis = WearingAccAxis()
        acc_axis.acc_axis_x = x_ctypes
        acc_axis.acc_axis_y = y_ctypes
        acc_axis.acc_axis_z = z_ctypes
        acc_axis.sensor_size = len(x_data)
        acc_axis.acc_bits = 16
        acc_axis.acc_range = 2
        acc_axis.sensor_type = 0

        return acc_axis
    
    def prepare_ppg_data(self, ppg_data):
        """准备PPG数据结构体"""
        if not isinstance(ppg_data, dict):
            raise ValueError("ppg_data must be a dictionary")
        
        ppg_sensors = WearingPpgSensors()
        
        def _process_ppg_channel(ppg_data, key):
            """通用函数处理 PPG 数据通道"""
            if key in ppg_data and len(ppg_data[key]) > 0:
                data = [int(x) for x in ppg_data[key]]
                ctypes_array = (ctypes.c_int32 * len(data))(*data)
                return ctypes_array, len(data)
            return None, 0

        # 处理绿光
        ppg_sensors.ppg_g, ppg_sensors.ppg_g_sensor_size = _process_ppg_channel(ppg_data, 'g')

        # 处理红光
        ppg_sensors.ppg_r, ppg_sensors.ppg_r_sensor_size = _process_ppg_channel(ppg_data, 'r')

        # 处理红外
        ppg_sensors.ppg_ir, ppg_sensors.ppg_ir_sensor_size = _process_ppg_channel(ppg_data, 'ir')

        # 处理低功耗红外
        ppg_sensors.ppg_low_ir, ppg_sensors.ppg_low_ir_sensor_size = _process_ppg_channel(ppg_data, 'low_ir')
        
        ppg_sensors.ppg_g_fs = ppg_data.get('fs', 25)
        ppg_sensors.channel_num = ppg_data.get('channel_num', 1)
        # 注意：Watch版本移除了 ppg_g_current 和 ppg_g_idac
        
        return ppg_sensors
    
    def prepare_sar_data(self, sar_data):
        """准备SAR数据结构体"""
        if not isinstance(sar_data, dict):
            raise ValueError("sar_data must be a dictionary")
        
        sar_sensors = SarSensors()
        
        if 'sar' in sar_data and sar_data['sar']:
            sar_values = [int(x) for x in sar_data['sar']]
            sar_ctypes = (ctypes.c_int32 * len(sar_values))(*sar_values)
            sar_sensors.sar = sar_ctypes
            sar_sensors.sar_size = len(sar_values)
        
        sar_sensors.sar_nv = sar_data.get('nv', 0)
        sar_sensors.sar_adjust = sar_data.get('adjust', 0)
        
        return sar_sensors
    
    def prepare_ambient_light_data(self, ambient_light_data):
        """准备环境光数据结构体"""
        if not isinstance(ambient_light_data, dict):
            raise ValueError("ambient_light_data must be a dictionary")
        
        ambient_sensors = WearingAmbientLightSensors()
        
        if 'ambient' in ambient_light_data and ambient_light_data['ambient']:
            ambient_values = [int(x) for x in ambient_light_data['ambient']]
            ambient_ctypes = (ctypes.c_int32 * len(ambient_values))(*ambient_values)
            ambient_sensors.ambient_light = ambient_ctypes
            ambient_sensors.ambient_light_sensor_size = len(ambient_values)
        
        ambient_sensors.ambient_light_channel_num = ambient_light_data.get('channel_num', 1)
        
        return ambient_sensors

    def get_version(self):
        return self.dll.get_wear_new_alg_version()
    
    def close(self):
        if not hasattr(self, '_dll_released') or not self._dll_released:
            try:
                # 在Windows上手动释放DLL
                if hasattr(self, 'dll_handle') and self.dll_handle is not None:
                    kernel32 = ctypes.windll.kernel32
                    kernel32.FreeLibrary.argtypes = [ctypes.c_void_p]
                    kernel32.FreeLibrary(self.dll_handle)
                else:
                    # pass
                    pass
                
                if hasattr(self, 'dll'):
                    del self.dll
                
                gc.collect()
                
                self._dll_released = True
                
            except Exception as e:
                print(f"Error releasing DLL: {e}")
                self._dll_released = True
    
    def __del__(self):
        self.close()
    
    def result_to_dict(self, result):
        # 根据 WearingResult 结构体更新
        return {
            'wear_flag': result.wear_flag,
            'error_no': result.error_no,
            'return_type': result.return_type,
            'wear_ir_result': result.wear_ir_result,
            'wear_green_result': result.wear_green_result,
            'wear_ambient_result': result.wear_ambient_result,
            'confusion': result.confusion,
            'peak_cnt': result.peak_cnt,
            'wear_rr_hr': result.wear_rr_hr,
            'ppg_dc_value': result.ppg_dc_value,
            'green_temp_flag_encode': result.green_temp_flag_encode,
            'wear_acc_momentum': result.wear_acc_momentum,
            'amb_std': result.amb_std,
            'init_timer': result.init_timer,
            'state': result.state
        }


# def generate_simulation_data(num_rows=10, fs=25):
#     """
#     生成模拟数据,包含佩戴和未佩戴两种情况
#     """
#     data_list = []
    
#     for i in range(num_rows):
#         duration = np.random.uniform(1.0, 2.0)
#         n_points = int(duration * fs)
        
#         t = np.linspace(0, duration, n_points)
        
#         # --- 模拟 ACC 数据 (手表模式,佩戴时Y轴可能受重力影响较大,取决于佩戴位置,这里复用基本逻辑) ---
#         acc_x = np.random.normal(0, 10, n_points)
#         acc_y = np.random.normal(0, 10, n_points)
#         acc_z = np.random.normal(1000, 20, n_points) # 假设 z轴朝下
        
#         acc_data = list(zip(acc_x.astype(int), acc_y.astype(int), acc_z.astype(int)))
        
#         # --- 模拟 PPG 数据 ---
#         if i < 5:
#             # 佩戴
#             heart_rate = 1.2
#             ppg_g = 2000 + 50 * np.sin(2 * np.pi * heart_rate * t) + np.random.normal(0, 5, n_points)
#             ppg_ir = 4000 + 100 * np.sin(2 * np.pi * heart_rate * t) + np.random.normal(0, 5, n_points)
#         else:
#             # 未佩戴
#             ppg_g = np.random.normal(100, 2, n_points)
#             ppg_ir = np.random.normal(100, 2, n_points)
            
#         ppg_g_data = ppg_g.astype(int).tolist()
#         ppg_ir_data = ppg_ir.astype(int).tolist()
        
#         data_list.append({
#             'acc_data': acc_data,
#             'ppg_g_data': ppg_g_data,
#             'ppg_ir_data': ppg_ir_data,
#             'data_len': n_points
#         })
        
#     return pd.DataFrame(data_list)


if __name__ == "__main__":
    results = []
    # 用户提供的DLL路径
    dll_path = r"G:\AlgorithmLibrary\01_alg_wearing\build\bin\libalg_wear.dll"
    
    print(f"Loading DLL from: {dll_path}")
    
    # df = generate_simulation_data(num_rows=10, fs=25)
    
    try:
        with WearDetectionWatchDLL(dll_path) as dll:
            version = dll.get_version()
            print(f"Watch Alg Ver: {version.major}.{version.minor}.{version.patch}")
            
            # 手表模式默认初始化 (is_ring=False)
            dll.init_default(is_ring=False)

            # for idx, row in df.iterrows():
                
            #     # 1. 准备 ACC
            #     acc_data = row['acc_data']
            #     acc_axis = dll.prepare_acc_data(acc_data)

            #     # 2. 准备 PPG
            #     ppg_g = row['ppg_g_data']
            #     ppg_ir = row['ppg_ir_data']
                
            #     print(f"Processing row {idx}, Len: {row['data_len']}")

            #     # 构造 ppg_data 字典
            #     ppg_config = {
            #         'g': ppg_g,
            #         'low_ir': ppg_ir,
            #         'channel_num': 1,
            #         'fs': 25, 
            #     }
            #     ppg_sensors = dll.prepare_ppg_data(ppg_config)

            #     # 3. 准备 WearingData
            #     wearing_data = WearingData()
            #     wearing_data.measure_type = WearMeasureType.WEAR_IR

            #     # 4. 执行
            #     result = dll.process(acc_axis=acc_axis, ppg_sensors=ppg_sensors, wearing_data=wearing_data)
            #     result_dict = dll.result_to_dict(result)
                
            #     print(f"  -> Result: wear_flag={result_dict['wear_flag']}, ret={result_dict['return_type']}")
                
            #     results.append(result_dict)

            # print(f"\nSuccessfully processed {len(results)} rows.")

    except OSError as e:
        print(f"Error loading DLL: {e}")
        print("Please check if the DLL path exists and matches your Python architecture (32-bit/64-bit).")
    except Exception as e:
        print(f"\nError occurred: {e}")
